"""IDs + memory for every message the AI writes (1.17.0).

Every AI answer starts with a short id, e.g. `#13345`. The id lets you

    .reply 13345 <text>        talk to exactly that answer (the bot replies to the original AI message)
    (Reply on an AI message)   `.ask ...` / `.do ...` knows which message you mean - with or without an id

and `.storage on` keeps the conversations for a long time (see `StorageMode`).

Short-term mode (default): the last SHORT_KEEP_ROWS answers of the last SHORT_KEEP_DAYS days are kept so that
`.reply <id>` and Reply-on-an-AI-message work. Long-term mode (`.storage on`): up to LONG_KEEP_ROWS, no expiry, and every
`.ask` in a chat continues that chat's recent conversation automatically.

Pure Python + the account's own database: it never talks to Telegram, so it is easy to test.
"""
from __future__ import annotations

import re
import time
from typing import Any

FIRST_ID = 10000
SHORT_KEEP_ROWS = 60
SHORT_KEEP_DAYS = 3
LONG_KEEP_ROWS = 5000
HISTORY_PAIRS = 6          # exchanges added automatically in long-term mode
HISTORY_CHARS = 6000       # budget of the history that is sent to the model
CHAIN_DEPTH = 8            # how far back a reply chain is followed

TABLE = ("CREATE TABLE IF NOT EXISTS ai_msgs (aid INTEGER PRIMARY KEY, chat_id INTEGER NOT NULL, msg_id INTEGER NOT NULL, "
         "kind TEXT NOT NULL DEFAULT 'ask', question TEXT NOT NULL DEFAULT '', answer TEXT NOT NULL DEFAULT '', "
         "parent INTEGER, created REAL NOT NULL)")
INDEX = "CREATE INDEX IF NOT EXISTS ai_msgs_chat ON ai_msgs(chat_id, msg_id)"

TAG_RE = re.compile(r"^\s*#(\d{4,9})(?!\d)")
LEAD_RE = re.compile(r"^\s*(?:#\d{4,9}\s*)?(?:↩️\s*#\d{4,9}\s*)?(?:🤖|🔎|🖼|🧾|🌐)?\s*")


def tag(aid: int) -> str:
    return f"#{int(aid)}"


def parse_tag(text: str | None) -> int | None:
    """`#13345 🤖 ...` -> 13345 (only a tag at the very start counts)."""
    m = TAG_RE.match(text or "")
    return int(m.group(1)) if m else None


def looks_like_ai_text(text: str | None) -> bool:
    t = (text or "").lstrip()
    return bool(TAG_RE.match(t)) or t.startswith(("🤖", "🔎 ", "🧾 "))


def strip_lead(text: str | None) -> str:
    """Remove the `#id` / `🤖` markers at the start of an AI message."""
    return LEAD_RE.sub("", text or "", count=1).strip()


def split_bubble(text: str | None) -> tuple[str, str]:
    """An AI message is `#id 🤖 <question>\\n\\n<answer>`: (question, answer). Without the blank line the whole text is the answer."""
    body = strip_lead(text)
    head, sep, rest = body.partition("\n\n")
    if sep and rest.strip():
        return head.strip(), rest.strip()
    return "", body


def trim_history(pairs: list[tuple[str, str]], limit: int = HISTORY_CHARS) -> list[tuple[str, str]]:
    """Keep the NEWEST pairs that fit in `limit` characters (each side is shortened when it is very long)."""
    out: list[tuple[str, str]] = []
    used = 0
    for q, a in reversed(pairs):
        q, a = (q or "")[:1200], (a or "")[:2400]
        if used + len(q) + len(a) > limit and out:
            break
        out.append((q, a))
        used += len(q) + len(a)
    out.reverse()
    return out


def history_messages(pairs: list[tuple[str, str]]) -> list[dict[str, str]]:
    msgs: list[dict[str, str]] = []
    for q, a in pairs:
        if q.strip():
            msgs.append({"role": "user", "content": q})
        if a.strip():
            msgs.append({"role": "assistant", "content": a})
    return msgs


class AIThreads:
    def __init__(self, db: Any):
        self.db = db
        self._ready = False
        self._storage: bool | None = None

    async def ensure(self) -> None:
        if not self._ready:
            self._ready = True
            await self.db.execute(TABLE)
            await self.db.execute(INDEX)

    # ------------------------------------------------------------------ storage switch
    async def storage_on(self) -> bool:
        if self._storage is None:
            self._storage = bool(await self.db.get_kv("ai_storage_on", False))
        return self._storage

    async def set_storage(self, on: bool) -> None:
        self._storage = bool(on)
        await self.db.set_kv("ai_storage_on", bool(on))
        await self.prune()

    # ------------------------------------------------------------------ ids / records
    async def new_id(self) -> int:
        await self.ensure()
        row = await self.db.fetchone("SELECT MAX(aid) AS m FROM ai_msgs")
        seq = int(await self.db.get_kv("ai_aid_seq", FIRST_ID) or FIRST_ID)
        top = int(row["m"]) if row and row["m"] is not None else 0
        aid = max(seq, top) + 1
        await self.db.set_kv("ai_aid_seq", aid)
        return aid

    async def record(self, aid: int, chat_id: int, msg_id: int, *, kind: str, question: str, answer: str, parent: int | None = None) -> None:
        await self.ensure()
        await self.db.execute(
            "INSERT OR REPLACE INTO ai_msgs(aid,chat_id,msg_id,kind,question,answer,parent,created) VALUES(?,?,?,?,?,?,?,?)",
            (int(aid), int(chat_id), int(msg_id), kind, (question or "")[:4000], (answer or "")[:12000], parent, time.time()))
        await self.prune()

    async def by_aid(self, aid: int) -> dict | None:
        await self.ensure()
        row = await self.db.fetchone("SELECT * FROM ai_msgs WHERE aid=?", (int(aid),))
        return dict(row) if row else None

    async def by_msg(self, chat_id: int, msg_id: int) -> dict | None:
        await self.ensure()
        row = await self.db.fetchone("SELECT * FROM ai_msgs WHERE chat_id=? AND msg_id=? ORDER BY aid DESC LIMIT 1", (int(chat_id), int(msg_id)))
        return dict(row) if row else None

    async def find(self, chat_id: int, msg: Any) -> dict | None:
        """The stored record of a Telegram message (looked up by chat+message id, then by the `#id` written in its text)."""
        if msg is None:
            return None
        mid = getattr(msg, "id", None)
        if mid is not None:
            rec = await self.by_msg(chat_id, int(mid))
            if rec:
                return rec
        aid = parse_tag(getattr(msg, "message", None) or getattr(msg, "raw_text", None))
        return await self.by_aid(aid) if aid else None

    async def chain(self, aid: int, depth: int = CHAIN_DEPTH) -> list[dict]:
        """The conversation that ends at `aid`, oldest first (follows `parent`)."""
        out: list[dict] = []
        seen: set[int] = set()
        cur: int | None = int(aid)
        while cur and cur not in seen and len(out) < depth:
            seen.add(cur)
            rec = await self.by_aid(cur)
            if not rec:
                break
            out.append(rec)
            cur = rec.get("parent")
        out.reverse()
        return out

    async def recent(self, chat_id: int, n: int = HISTORY_PAIRS) -> list[dict]:
        await self.ensure()
        rows = await self.db.fetchall("SELECT * FROM ai_msgs WHERE chat_id=? AND kind IN ('ask','reply','web','guide') ORDER BY aid DESC LIMIT ?", (int(chat_id), int(n)))
        return [dict(r) for r in reversed(rows)]

    async def count(self) -> int:
        await self.ensure()
        row = await self.db.fetchone("SELECT COUNT(*) AS n FROM ai_msgs")
        return int(row["n"]) if row else 0

    async def clear(self, chat_id: int | None = None) -> int:
        await self.ensure()
        if chat_id is None:
            return max(await self.db.execute("DELETE FROM ai_msgs"), 0)
        return max(await self.db.execute("DELETE FROM ai_msgs WHERE chat_id=?", (int(chat_id),)), 0)

    async def prune(self) -> None:
        await self.ensure()
        keep = LONG_KEEP_ROWS if await self.storage_on() else SHORT_KEEP_ROWS
        await self.db.execute("DELETE FROM ai_msgs WHERE aid NOT IN (SELECT aid FROM ai_msgs ORDER BY aid DESC LIMIT ?)", (keep,))
        if not await self.storage_on():
            await self.db.execute("DELETE FROM ai_msgs WHERE created < ?", (time.time() - SHORT_KEEP_DAYS * 86400,))

    # ------------------------------------------------------------------ building the model's history
    async def history_for(self, chat_id: int, replied: Any = None) -> tuple[list[dict[str, str]], dict | None]:
        """(history messages, the AI record that was replied to or None).

        * replied message is an AI message  -> its whole conversation (works with storage off too; when the id is not in the
          database any more, the text of the bubble itself is used);
        * otherwise, with `.storage on`     -> the last exchanges of this chat.
        """
        rec = await self.find(chat_id, replied)
        if rec:
            pairs = [(r["question"], r["answer"]) for r in await self.chain(rec["aid"])]
            return history_messages(trim_history(pairs)), rec
        if replied is not None and looks_like_ai_text(getattr(replied, "message", None)):
            q, a = split_bubble(getattr(replied, "message", None))
            return history_messages(trim_history([(q, a)])), {"aid": parse_tag(getattr(replied, "message", None)), "question": q, "answer": a, "chat_id": chat_id, "msg_id": getattr(replied, "id", 0)}
        if await self.storage_on():
            pairs = [(r["question"], r["answer"]) for r in await self.recent(chat_id)]
            return history_messages(trim_history(pairs)), None
        return [], None


# ------------------------------------------------------------------ shared by every AI command
def get_threads(client: Any, db: Any) -> AIThreads:
    th = getattr(client, "_hapoyi_ai_threads", None)
    if th is None:
        th = client._hapoyi_ai_threads = AIThreads(db)
    return th


async def publish(client: Any, db: Any, event: Any, header: str, text: str, *, kind: str = "ask", question: str = "",
                  parent: int | None = None, footer: str = "", limit: int = 3900, **edit_kw: Any) -> int:
    """Write the answer into the command message: `#id header\\n\\ntext` and remember it. Returns the id."""
    th = get_threads(client, db)
    aid = await th.new_id()
    head = f"{tag(aid)} {header}".rstrip()
    body = f"{head}\n\n{text}" + (f"\n\n{footer}" if footer else "")
    if len(body) > limit:
        room = max(200, limit - len(head) - len(footer) - 8)
        body = f"{head}\n\n{text[: room - 1]}…" + (f"\n\n{footer}" if footer else "")
    res = await event.edit(body, **edit_kw)
    msg_id = getattr(res, "id", None) or getattr(event, "id", 0) or 0
    await th.record(aid, event.chat_id, int(msg_id), kind=kind, question=question or header, answer=text, parent=parent)
    return aid
