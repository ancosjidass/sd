"""1.19.6: delegate level `god` - the command is run exactly like the owner typing it by hand (admins included); `mod` / `full` / admins are unchanged."""
from __future__ import annotations

import asyncio
import pathlib
import sys
from datetime import datetime, timezone
from types import SimpleNamespace

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))

from tests.test_v1180 import GEvent, _adm, _gb_env  # noqa: E402


def test_god_may_run_every_group_command_the_others_stay_limited():
    GB = _gb_env({})[0]
    ok = lambda cmd, **kw: GB.allowed(cmd, **{"is_admin": False, "rights": set(), "is_creator": False, "level": None, **kw})  # noqa: E731
    for cmd in GB.RIGHT:
        assert ok(cmd, level="god"), cmd
    assert not ok("promote", level="mod") and ok("promote", level="full") and ok("promote", level="god")
    assert not ok("ban", level=None) and not ok("gbot", level="god")          # not a delegate -> nothing; `gbot` is never reachable
    assert ok("ban", is_admin=True, rights={"ban_users"}) and not ok("ban", is_admin=True, rights=set())   # admins: unchanged


def test_god_acts_on_admins_but_mod_full_and_admins_still_cannot():
    perms = {556: _adm(), 7: _adm()}                 # 556 = an admin (the victim), 7 = an ordinary admin requester
    GB, ctrl, client, db, fed = _gb_env(perms)

    async def run():
        await ctrl.ensure()
        now = datetime.now(timezone.utc).isoformat()
        await db.execute("INSERT INTO gb_chats(chat_id,enabled) VALUES(-1001,1)")
        for uid, lvl in ((31, "mod"), (32, "full"), (33, "god")):
            await db.execute("INSERT INTO gb_delegates(chat_id,user_id,level,name,created_at) VALUES(-1001,?,?,?,?)", (uid, lvl, lvl, now))
        victim = SimpleNamespace(id=42, sender_id=556)
        for uid in (7, 31, 32):
            ev = GEvent("بن", uid, victim)
            await ctrl.handle(ev)
            await asyncio.sleep(1.05)
            assert not fed and ev.replied and "ادمین" in ev.replied[0], uid
        ev = GEvent("بن", 33, victim)
        await ctrl.handle(ev)
        assert fed == [(".ban", 42)] and not ev.replied                       # god: handed to the real `.ban` -> Telegram decides
        await asyncio.sleep(1.05)
        await ctrl.handle(GEvent("ارتقا", 33, victim))                         # also promote / demote
        assert fed[-1] == (".promote", 42)
        for t in list(ctrl.tasks):
            t.cancel()
    asyncio.run(run())
