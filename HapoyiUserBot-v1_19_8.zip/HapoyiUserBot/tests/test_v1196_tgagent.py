"""1.19.6: the AI account agent (modules/tg_agent.py): router, smart narrowing, budgets, staged destructive actions, confirmation."""
from __future__ import annotations

import asyncio
import json
import pathlib
import sys
import time
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))

from telethon import types  # noqa: E402

from modules import tg_agent as T  # noqa: E402
from tests.test_v1170 import make_db  # noqa: E402
from tests.test_v1196_features import FakeClient  # noqa: E402

NOW = datetime.now(timezone.utc)


def dlg(id, title, kind="channel", username="", last_hours=1.0, last="", unread=0, pinned=False):
    if kind == "bot":
        ent = types.User(id=id, bot=True, first_name=title, username=username or None)
    elif kind == "user":
        ent = types.User(id=id, first_name=title)
    elif kind == "group":
        ent = types.Channel(id=id, title=title, photo=types.ChatPhotoEmpty(), date=NOW, megagroup=True, access_hash=1)
    else:
        ent = types.Channel(id=id, title=title, photo=types.ChatPhotoEmpty(), date=NOW, broadcast=True, access_hash=1)
    return T.Dlg(id=id, title=title, username=username, kind=kind, unread=unread, last_text=last, last_date=NOW - timedelta(hours=last_hours), muted=False, archived=False, pinned=pinned,
                 entity=ent)


def test_router_sends_only_account_chores_to_the_agent():
    yes = ["از چنل‌های خبری که جوینم بگو امروز جنگه یا نه", "بحث امروز چیه", "اخبار امروز چیه", "منو توی https://t.me/abc عضو کن", "از این چنلا لفت بده",
           "بات هایی که کانفیگ دارن رو بلاک کن و چتشون رو دیلیت کن", "check my channels for today's news"]
    no = ["هر ۵ دقیقه بنویس میو", "یه تایمر ۵ دقیقه ای بذار", "دانلود این ویدیو", "ربات فلانی رو سکوت کن", "قیمت دلار چنده", "یه اتو ریپلای بساز"]
    assert all(T.wants(q) for q in yes) and not any(T.wants(q) for q in no)


def test_news_ranking_prefers_newsy_and_fresh_channels():
    rows = [dlg(1, "خبرگزاری تسنیم", last_hours=1), dlg(2, "Memes", last_hours=1), dlg(3, "اخبار فوری", last_hours=30), dlg(4, "BBC Persian news", last_hours=2)]
    ranked = sorted(rows, key=lambda d: -T.news_score(d, NOW))
    assert [d.id for d in ranked][:2] == [4, 1] or [d.id for d in ranked][:2] == [1, 4]
    assert ranked[-1].id == 2


def test_bulk_selection_is_done_in_code_and_spares_pinned_chats():
    rows = [dlg(1, "V2Ray Config Bot", "bot", "cfgbot"), dlg(2, "چت ناشناس", "bot"), dlg(3, "Helper", "bot", last="your config is ready"), dlg(4, "My pinned config bot", "bot", pinned=True),
            dlg(5, "Config channel", "channel"), dlg(6, "Weather bot", "bot"), dlg(777000, "Telegram", "user")]
    hit = T.select_bulk(rows, "bot", ["config", "کانفیگ", "ناشناس"])
    assert [d.id for d in hit] == [1, 2, 3]                                   # not the pinned one, not channels, not other bots
    assert [d.id for d in T.select_bulk(rows, "bot", ["config"], where="name")] == [1]
    assert T.select_bulk(rows, "bot", []) == []


def make_env(script, dialogs, search_hits=()):
    c, answers = FakeClient(), iter(script)
    seen = []

    async def ask(messages, **kw):
        seen.append(messages)
        return next(answers), None
    c._hapoyi_ask_ai = ask
    acts = []

    async def get_dialogs(limit=400):
        return [SimpleNamespace(id=d.id, name=d.title, entity=d.entity, unread_count=d.unread, message=SimpleNamespace(message=d.last_text, date=d.last_date), archived=False, pinned=d.pinned,
                                dialog=SimpleNamespace(notify_settings=None)) for d in dialogs]

    async def iter_messages(entity, limit=20, search=None):
        if entity is None:
            for text, chat, hours in search_hits:
                yield SimpleNamespace(date=NOW - timedelta(hours=hours), message=text, chat=types.Channel(id=1, title=chat, photo=types.ChatPhotoEmpty(), date=NOW, broadcast=True, access_hash=1),
                                      chat_id=1)
        else:
            for text in [f"post {i} about {search}" for i in range(3)]:
                yield SimpleNamespace(date=NOW - timedelta(hours=1), message=text, chat=entity, chat_id=1)
    c.get_dialogs, c.iter_messages = get_dialogs, iter_messages
    c.delete_dialog = lambda ent, revoke=False: acts.append(("delete", ent.id)) or asyncio.sleep(0)
    c.get_input_entity = lambda ent: asyncio.sleep(0, result=SimpleNamespace(id=getattr(ent, "id", 0)))

    async def call(req):
        acts.append((req.__class__.__name__,))
    FakeClient.__call__ = lambda self, req: call(req)
    return c, seen, acts


class Ev:
    chat_id = 5

    def __init__(self):
        self.edits = []
        self.pattern_match = SimpleNamespace(group=lambda i: "")

    async def edit(self, text, **kw):
        self.edits.append(text)

    async def delete(self):
        pass


def test_news_question_uses_one_global_search_and_stops(monkeypatch):
    monkeypatch.delenv("SANDBOX_URL", raising=False)
    hits = [(f"حمله موشکی گزارش {i}", "تسنیم" if i % 2 else "فارس", 2) for i in range(7)]
    script = [json.dumps({"say": "جستجو", "do": [{"t": "search", "q": "حمله موشکی", "hours": 24}]}), json.dumps({"done": "طبق تسنیم و فارس امروز درگیری گزارش شده."})]

    async def go():
        c, seen, acts = make_env(script, [dlg(1, "تسنیم"), dlg(2, "فارس")], hits)
        db = await make_db()
        T.setup(c, db)
        ev = Ev()
        await c._hapoyi_tg_run(ev, "از چنل‌های خبری بگو امروز جنگه یا نه")
        assert len(seen) == 2                                                  # exactly: plan the search, answer. No channel was read one by one.
        assert "<<<DATA search" in seen[1][-1]["content"] and "this is probably enough" in seen[1][-1]["content"]
        assert "درگیری" in ev.edits[-1] and "7 پیام از 2 گپ" in ev.edits[-1]
        assert acts == []
    asyncio.run(go())


def test_read_budget_is_enforced_in_code(monkeypatch):
    monkeypatch.delenv("SANDBOX_URL", raising=False)
    reads = [json.dumps({"do": [{"t": "read", "chat": str(i), "q": "war"}]}) for i in (1, 2, 3, 4)]
    script = reads + [json.dumps({"done": "نتیجه"})]

    async def go():
        c, seen, acts = make_env(script, [dlg(i, f"news {i}") for i in (1, 2, 3, 4)])
        T.setup(c, await make_db())
        ev = Ev()
        await c._hapoyi_tg_run(ev, "چنل‌ها رو چک کن")
        assert any("BUDGET: no more reads" in m["content"] for call in seen for m in call if m["role"] == "user")
        assert "نتیجه" in ev.edits[-1]
    asyncio.run(go())


def test_destructive_actions_wait_for_yes_when_something_external_was_read(monkeypatch):
    monkeypatch.delenv("SANDBOX_URL", raising=False)
    script = [json.dumps({"do": [{"t": "read", "chat": "1"}, {"t": "leave", "chat": "2"}]}), json.dumps({"done": "لفت می‌دم"})]

    async def go():
        c, seen, acts = make_env(script, [dlg(1, "news"), dlg(2, "spam channel")])
        T.setup(c, await make_db())
        c._hapoyi_ai_pending = {}
        ev = Ev()
        await c._hapoyi_tg_run(ev, "از چنل spam لفت بده")
        assert acts == []                                                      # a channel text was read -> a prompt injection could be behind the «leave»: nothing ran
        assert "بله" in ev.edits[-1] and "spam channel" in ev.edits[-1] and 5 in c._hapoyi_ai_pending
        pend = c._hapoyi_ai_pending.pop(5)
        await pend["callback"](pend["event"])
        assert acts == [("delete", 2)] and "انجام شد" in ev.edits[-1]
    asyncio.run(go())


def test_clean_request_runs_at_once_but_a_big_bulk_needs_approval(monkeypatch):
    monkeypatch.delenv("SANDBOX_URL", raising=False)
    bulk = {"do": [{"t": "bulk", "kind": "bot", "match": ["config", "کانفیگ"], "do": "block_delete"}]}

    async def go():
        small = [dlg(i, f"Config Bot {i}", "bot") for i in range(1, 4)]
        c, seen, acts = make_env([json.dumps(bulk), json.dumps({"done": "بلاک شدند"})], small + [dlg(50, "Friend bot", "bot")])
        db = await make_db()
        T.setup(c, db)
        c._hapoyi_ai_pending = {}
        ev = Ev()
        await c._hapoyi_tg_run(ev, "بات‌های کانفیگ رو بلاک کن و چتشون رو پاک کن")
        assert [a[0] for a in acts].count("BlockRequest") == 3 and ("delete", 50) not in acts and not c._hapoyi_ai_pending
        big = [dlg(i, f"Config Bot {i}", "bot") for i in range(1, 13)]
        c2, _, acts2 = make_env([json.dumps(bulk), json.dumps({"done": "ok"})], big)
        T.setup(c2, db)
        c2._hapoyi_ai_pending = {}
        ev2 = Ev()
        await c2._hapoyi_tg_run(ev2, "بات‌های کانفیگ رو بلاک کن")
        assert acts2 == [] and 5 in c2._hapoyi_ai_pending and "بیش از 10" in ev2.edits[-1]
    asyncio.run(go())


def test_answers_never_carry_secrets(monkeypatch):
    monkeypatch.delenv("SANDBOX_URL", raising=False)
    monkeypatch.setenv("BOT_TOKEN", "123456789:AAH-abcdefghijklmnopqrstuvwxyz012345")

    async def go():
        c, seen, acts = make_env([json.dumps({"done": "token: 123456789:AAH-abcdefghijklmnopqrstuvwxyz012345"})], [])
        T.setup(c, await make_db())
        ev = Ev()
        await c._hapoyi_tg_run(ev, "اخبار امروز")
        assert "AAH-" not in ev.edits[-1] and "⟦hidden⟧" in ev.edits[-1]
    asyncio.run(go())


def test_do_routes_news_to_the_agent_and_pending_callbacks_resolve():
    src = (pathlib.Path(__file__).resolve().parents[1] / "modules" / "ai_agent.py").read_text(encoding="utf-8")
    assert "_hapoyi_tg_wants" in src and 'pend["kind"] == "callback"' in src and "_hapoyi_ai_pending" in src
