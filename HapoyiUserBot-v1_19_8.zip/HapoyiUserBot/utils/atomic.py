"""Write a file safely: temp file + rename, and when the rename is refused (a file that is a Docker/bind mount, a network or overlay file system:
`OSError: [Errno 16] Device or resource busy`) write the target in place instead."""
from __future__ import annotations

import os
import stat
import tempfile
from pathlib import Path


def write_text_atomic(path: str | Path, text: str, *, encoding: str = "utf-8", private: bool = False) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = None
    try:
        fd, tmp = tempfile.mkstemp(dir=str(p.parent), suffix=".tmp")
        with os.fdopen(fd, "w", encoding=encoding) as fh:
            fh.write(text)
        if private:
            try:
                os.chmod(tmp, stat.S_IRUSR | stat.S_IWUSR)
            except OSError:
                pass
        os.replace(tmp, p)
        return
    except OSError:
        pass  # EBUSY / EXDEV / EPERM on rename (or no permission for a temp file in that folder): fall back below
    finally:
        if tmp:
            try:
                os.remove(tmp)
            except OSError:
                pass
    with open(p, "w", encoding=encoding) as fh:  # in place; raises a real error if the file is really not writable
        fh.write(text)
        fh.flush()
        try:
            os.fsync(fh.fileno())
        except OSError:
            pass
    if private:
        try:
            os.chmod(p, stat.S_IRUSR | stat.S_IWUSR)
        except OSError:
            pass
