"""Run a command of the self AS THE OWNER from code (rules, undo, typo-fix, scheduled actions).

Telethon never dispatches a message that this same session sends, so `send_message(".ban x")` alone is only text. The message is sent and then handed
to the real command handlers (`client._hapoyi_feed_handlers`, modules/ai_agent.py) - exactly what the AI / «ربات …» do."""
from __future__ import annotations

import asyncio
import logging
from typing import Any

log = logging.getLogger(__name__)


async def run_as_me(client: Any, chat_id: Any, text: str, *, reply_to: int | None = None, replied: Any = None, delete_after: float | None = None) -> int:
    """Send `text` into the chat and run it through the command handlers. Returns how many handlers took it (0 = it stayed plain text)."""
    sent = await client.send_message(chat_id, text, reply_to=reply_to, parse_mode=None)
    feed = getattr(client, "_hapoyi_feed_handlers", None)
    n = 0
    if feed is not None and sent is not None:
        from modules.groupbot import _Origin  # noqa: PLC0415

        try:
            n = await feed(sent, _Origin(client, getattr(sent, "chat_id", chat_id)), replied)
        except Exception:  # noqa: BLE001
            log.exception("run_as_me: handlers failed for %r", text[:60])
    if delete_after and sent is not None:
        async def later():
            await asyncio.sleep(delete_after)
            try:
                await client.delete_messages(sent.chat_id, [sent.id])
            except Exception:  # noqa: BLE001
                pass
        asyncio.get_running_loop().create_task(later())
    return n
