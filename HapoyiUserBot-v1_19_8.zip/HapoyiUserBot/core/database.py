from __future__ import annotations

import asyncio
import json
import sqlite3
from collections.abc import Iterable
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from core.licenses import SCHEMA as LICENSE_SCHEMA


SCHEMA = r"""
PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;
PRAGMA busy_timeout=5000;
CREATE TABLE IF NOT EXISTS kv (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS chat_settings (
    chat_id INTEGER PRIMARY KEY,
    settings_json TEXT NOT NULL DEFAULT '{}',
    updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS warnings (
    chat_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    count INTEGER NOT NULL DEFAULT 0,
    last_reason TEXT,
    updated_at TEXT NOT NULL,
    PRIMARY KEY(chat_id, user_id)
);
CREATE TABLE IF NOT EXISTS whitelist (
    chat_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    PRIMARY KEY(chat_id, user_id)
);
CREATE TABLE IF NOT EXISTS autoban (
    chat_id INTEGER PRIMARY KEY,
    enabled INTEGER NOT NULL DEFAULT 0,
    action TEXT NOT NULL DEFAULT 'ban',
    updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS autodelete (
    chat_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    enabled INTEGER NOT NULL DEFAULT 1,
    enabled_at TEXT NOT NULL,
    PRIMARY KEY(chat_id, user_id)
);
CREATE TABLE IF NOT EXISTS autoreplies (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    scope_type TEXT NOT NULL,
    scope_id INTEGER NOT NULL DEFAULT 0,
    trigger TEXT NOT NULL,
    response TEXT NOT NULL,
    mode TEXT NOT NULL DEFAULT 'contains',
    enabled INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS notes (
    owner_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    value TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    PRIMARY KEY(owner_id, name)
);
CREATE TABLE IF NOT EXISTS jobs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_id INTEGER NOT NULL,
    chat_id INTEGER,
    kind TEXT NOT NULL,
    payload_json TEXT NOT NULL,
    run_at TEXT NOT NULL,
    interval_seconds INTEGER,
    enabled INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS price_alerts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_id INTEGER NOT NULL,
    chat_id INTEGER NOT NULL,
    symbol TEXT NOT NULL,
    operator TEXT NOT NULL,
    target REAL NOT NULL,
    currency TEXT NOT NULL DEFAULT 'USD',
    enabled INTEGER NOT NULL DEFAULT 1,
    last_value REAL,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS filters (
    chat_id INTEGER NOT NULL,
    pattern TEXT NOT NULL,
    action TEXT NOT NULL,
    enabled INTEGER NOT NULL DEFAULT 1,
    PRIMARY KEY(chat_id, pattern, action)
);
CREATE TABLE IF NOT EXISTS afk (
    owner_id INTEGER PRIMARY KEY,
    reason TEXT,
    started_at TEXT NOT NULL,
    enabled INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS afk_notified (
    owner_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    notified_at TEXT NOT NULL,
    PRIMARY KEY(owner_id, user_id)
);
CREATE TABLE IF NOT EXISTS echo_users (
    chat_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    name TEXT,
    created_at TEXT NOT NULL,
    PRIMARY KEY(chat_id, user_id)
);
CREATE TABLE IF NOT EXISTS echo_messages (
    chat_id INTEGER NOT NULL,
    message_id INTEGER NOT NULL,
    source_user_id INTEGER NOT NULL,
    source_name TEXT,
    source_msg_id INTEGER,
    text TEXT,
    created_at TEXT NOT NULL,
    PRIMARY KEY(chat_id, message_id)
);
CREATE TABLE IF NOT EXISTS todos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_id INTEGER NOT NULL,
    text TEXT NOT NULL,
    done INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS repeat_jobs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id INTEGER NOT NULL,
    text TEXT NOT NULL,
    interval_s INTEGER NOT NULL,
    next_run REAL NOT NULL,
    remaining INTEGER,
    enabled INTEGER NOT NULL DEFAULT 1,
    sent INTEGER NOT NULL DEFAULT 0,
    reply_to INTEGER,
    last_error TEXT,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS delete_jobs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id INTEGER NOT NULL,
    message_ids TEXT NOT NULL,
    run_at REAL NOT NULL,
    kind TEXT NOT NULL DEFAULT 'selfdestruct',
    preview TEXT,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS user_reactions (
    chat_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL DEFAULT 0,
    emoji TEXT NOT NULL,
    enabled INTEGER NOT NULL DEFAULT 1,
    PRIMARY KEY(chat_id, user_id)
);
CREATE TABLE IF NOT EXISTS first_comments (
    channel_id INTEGER PRIMARY KEY,
    title TEXT,
    text TEXT NOT NULL,
    enabled INTEGER NOT NULL DEFAULT 1,
    posted INTEGER NOT NULL DEFAULT 0,
    last_status TEXT,
    last_at TEXT,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS reactions (
    chat_id INTEGER PRIMARY KEY,
    emoji TEXT,
    enabled INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS watches (
    owner_id INTEGER NOT NULL,
    chat_id INTEGER NOT NULL,
    kind TEXT NOT NULL,
    needle TEXT,
    enabled INTEGER NOT NULL DEFAULT 1,
    PRIMARY KEY(owner_id, chat_id, kind, needle)
);
CREATE TABLE IF NOT EXISTS game_runs (
    owner_id INTEGER NOT NULL,
    chat_id INTEGER NOT NULL,
    game TEXT NOT NULL,
    started_at TEXT NOT NULL,
    PRIMARY KEY(owner_id, chat_id, game)
);
CREATE TABLE IF NOT EXISTS portfolio (
    owner_id INTEGER NOT NULL,
    symbol TEXT NOT NULL,
    quantity REAL NOT NULL,
    updated_at TEXT NOT NULL,
    PRIMARY KEY(owner_id, symbol)
);
CREATE TABLE IF NOT EXISTS notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_id INTEGER NOT NULL,
    chat_id INTEGER NOT NULL,
    needle TEXT NOT NULL,
    enabled INTEGER NOT NULL DEFAULT 1,
    UNIQUE(owner_id, chat_id, needle)
);
CREATE TABLE IF NOT EXISTS relations (
    owner_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    kind TEXT NOT NULL CHECK(kind IN ('friend','enemy')),
    enabled INTEGER NOT NULL DEFAULT 1,
    cooldown_seconds REAL NOT NULL DEFAULT 8,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    PRIMARY KEY(owner_id, user_id)
);
CREATE TABLE IF NOT EXISTS relation_replies (
    owner_id INTEGER NOT NULL,
    kind TEXT NOT NULL CHECK(kind IN ('friend','enemy')),
    reply_text TEXT NOT NULL,
    enabled INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS game_scores (
    owner_id INTEGER NOT NULL,
    chat_id INTEGER NOT NULL,
    game TEXT NOT NULL,
    wins INTEGER NOT NULL DEFAULT 0,
    plays INTEGER NOT NULL DEFAULT 0,
    points INTEGER NOT NULL DEFAULT 0,
    updated_at TEXT NOT NULL,
    PRIMARY KEY(owner_id, chat_id, game)
);
"""


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


class Database:
    def __init__(self, path: str | Path, *, control: bool = False):
        """`control=True` (main database only) also creates the license / fleet tables."""
        self.path = str(path)
        self.control = control
        self._conn: sqlite3.Connection | None = None
        self._lock = asyncio.Lock()

    async def connect(self) -> None:
        async with self._lock:
            if self._conn is not None:
                return
            self._conn = sqlite3.connect(self.path, check_same_thread=False)
            self._conn.row_factory = sqlite3.Row
            self._conn.executescript(SCHEMA)
            if self.control:
                self._conn.executescript(LICENSE_SCHEMA)
            self._conn.commit()

    async def close(self) -> None:
        async with self._lock:
            if self._conn is not None:
                self._conn.close()
                self._conn = None

    def _require(self) -> sqlite3.Connection:
        if self._conn is None:
            raise RuntimeError("Database is not connected")
        return self._conn

    async def execute(self, sql: str, params: Iterable[Any] = ()) -> int:
        async with self._lock:
            conn = self._require()
            cur = conn.execute(sql, tuple(params))
            conn.commit()
            return cur.rowcount

    async def backup_to(self, dest_path: str) -> None:
        """Consistent snapshot of the whole database (safe while the bot keeps writing)."""
        async with self._lock:
            conn = self._require()
            dest = sqlite3.connect(dest_path)
            try:
                conn.backup(dest)
            finally:
                dest.close()

    async def restore_from(self, src_path: str, *, skip_prefixes: tuple[str, ...] = ("fleet_", "licenses", "sqlite_")) -> tuple[int, int]:
        """Replace the CONTENT of every table that exists both here and in the backup file (shared columns only).
        Tables that only exist in the live database (newer than the backup) are left alone, and the license / fleet
        tables of the control database are never touched. Returns (tables, rows). All-or-nothing."""
        async with self._lock:
            conn = self._require()
            conn.commit()
            conn.execute("ATTACH DATABASE ? AS bk", (src_path,))
            tables = rows = 0
            try:
                names = [r[0] for r in conn.execute("SELECT name FROM bk.sqlite_master WHERE type='table'")]
                live = {r[0] for r in conn.execute("SELECT name FROM main.sqlite_master WHERE type='table'")}
                for name in names:
                    if name not in live or name.startswith(skip_prefixes):
                        continue
                    mine = [r[1] for r in conn.execute(f'PRAGMA main.table_info("{name}")')]
                    theirs = {r[1] for r in conn.execute(f'PRAGMA bk.table_info("{name}")')}
                    cols = [c for c in mine if c in theirs]
                    if not cols:
                        continue
                    col_sql = ",".join(f'"{c}"' for c in cols)
                    conn.execute(f'DELETE FROM main."{name}"')
                    cur = conn.execute(f'INSERT INTO main."{name}"({col_sql}) SELECT {col_sql} FROM bk."{name}"')
                    tables += 1
                    rows += max(cur.rowcount, 0)
                conn.commit()
            except Exception:
                conn.rollback()
                raise
            finally:
                conn.execute("DETACH DATABASE bk")
            return tables, rows

    async def insert(self, sql: str, params: Iterable[Any] = ()) -> int:
        """Run an INSERT and return the new row id (0 when ignored)."""
        async with self._lock:
            conn = self._require()
            cur = conn.execute(sql, tuple(params))
            conn.commit()
            return int(cur.lastrowid or 0) if cur.rowcount > 0 else 0

    async def fetchone(self, sql: str, params: Iterable[Any] = ()) -> sqlite3.Row | None:
        async with self._lock:
            conn = self._require()
            return conn.execute(sql, tuple(params)).fetchone()

    async def fetchall(self, sql: str, params: Iterable[Any] = ()) -> list[sqlite3.Row]:
        async with self._lock:
            conn = self._require()
            return conn.execute(sql, tuple(params)).fetchall()

    async def set_kv(self, key: str, value: Any) -> None:
        payload = json.dumps(value, ensure_ascii=False)
        await self.execute("INSERT INTO kv(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, payload))

    async def get_kv(self, key: str, default: Any = None) -> Any:
        row = await self.fetchone("SELECT value FROM kv WHERE key=?", (key,))
        if not row:
            return default
        try:
            return json.loads(row["value"])
        except json.JSONDecodeError:
            return row["value"]

    async def update_chat_settings(self, chat_id: int, **changes: Any) -> dict[str, Any]:
        current = await self.get_kv(f"chat:{chat_id}", {})
        current.update(changes)
        await self.set_kv(f"chat:{chat_id}", current)
        return current

    async def get_chat_settings(self, chat_id: int) -> dict[str, Any]:
        return dict(await self.get_kv(f"chat:{chat_id}", {}) or {})
