from __future__ import annotations

import logging
from telethon import TelegramClient

from config import Settings

log = logging.getLogger(__name__)


def build_client(settings: Settings) -> TelegramClient:
    client = TelegramClient(
        settings.session,
        settings.api_id,
        settings.api_hash,
        sequential_updates=False,   # 1.19.5: one slow handler (a download, `.tag` ...) must never hold back every later command for minutes
        auto_reconnect=True,
        flood_sleep_threshold=60,
    )
    log.info("Telegram client initialized with Telethon 1.45.x")
    return client
