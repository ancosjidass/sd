"""Outgoing-request pacing (anti flood / anti report).

Every account is paced separately. Message sends and edits go through a GCRA limiter per chat plus one for the
whole account, so a burst of modules (tag, repeat, echo, timers, games...) cannot hammer Telegram. A FloodWait that
Telegram does send pauses *all* paced requests of that account until it is over (instead of every module
discovering it separately). Everything else (reading, typing actions, deleting) is untouched.

    THROTTLE=on|off            default on
    THROTTLE_SCALE=1.0         >1 = slower / safer, <1 = faster
"""
from __future__ import annotations

import asyncio
import logging
import os
import time
from typing import Any

from telethon import utils
from telethon.errors import FloodWaitError
from telethon.tl import functions

log = logging.getLogger(__name__)

SEND = tuple(getattr(functions.messages, n) for n in ("SendMessageRequest", "SendMediaRequest", "SendMultiMediaRequest",
                                                       "ForwardMessagesRequest") if hasattr(functions.messages, n))
EDIT = tuple(getattr(functions.messages, n) for n in ("EditMessageRequest",) if hasattr(functions.messages, n))
# (interval seconds, burst) - Telegram tolerates ~1 msg/s per private chat and ~20 msg/min per group
LIMITS = {"private": (1.0, 6), "group": (1.5, 10), "edit": (0.5, 10), "global": (0.04, 25)}


class Pacer:
    def __init__(self, scale: float = 1.0):
        self.scale = max(0.1, scale)
        self.tat: dict[Any, float] = {}
        self.paused_until = 0.0
        self.delayed = 0
        self.delay_total = 0.0
        self.flood_waits = 0

    def reserve(self, key: Any, kind: str, now: float) -> float:
        interval, burst = LIMITS[kind]
        interval *= self.scale
        tat = max(self.tat.get(key, 0.0), now) + interval
        self.tat[key] = tat
        if len(self.tat) > 4000:
            self.tat = {k: v for k, v in self.tat.items() if v > now}
        return max(0.0, tat - now - burst * interval)

    def delay_for(self, chat_key: Any, chat_kind: str, edit: bool, now: float) -> float:
        wait = max(0.0, self.paused_until - now)
        wait = max(wait, self.reserve(("g",), "global", now))
        wait = max(wait, self.reserve((chat_key, "e" if edit else "s"), "edit" if edit else chat_kind, now))
        return wait


def _peer_info(peer: Any) -> tuple[Any, str]:
    try:
        pid = utils.get_peer_id(peer)
    except Exception:  # noqa: BLE001
        return repr(peer)[:80], "group"
    return pid, ("private" if isinstance(pid, int) and pid > 0 else "group")


def install_throttle(client: Any) -> Pacer | None:
    if getattr(client, "_hapoyi_pacer", None) is not None:
        return client._hapoyi_pacer
    if os.getenv("THROTTLE", "on").lower() in {"0", "off", "false", "no"} or not hasattr(client, "_call"):
        return None
    try:
        scale = float(os.getenv("THROTTLE_SCALE", "1") or 1)
    except ValueError:
        scale = 1.0
    pacer = Pacer(scale)
    original = client._call

    async def paced_call(sender, request, *args, **kwargs):
        reqs = request if isinstance(request, (list, tuple)) else [request]
        first = reqs[0] if reqs else None
        is_edit = isinstance(first, EDIT)
        if isinstance(first, SEND) or is_edit:
            key, kind = _peer_info(getattr(first, "peer", None) or getattr(first, "to_peer", None))
            wait = pacer.delay_for(key, kind, is_edit, time.monotonic())
            if wait > 0.05:
                pacer.delayed += 1
                pacer.delay_total += wait
                await asyncio.sleep(wait)
        try:
            return await original(sender, request, *args, **kwargs)
        except FloodWaitError as exc:
            pacer.flood_waits += 1
            pacer.paused_until = max(pacer.paused_until, time.monotonic() + exc.seconds + 1)
            raise

    client._call = paced_call
    client._hapoyi_pacer = pacer
    return pacer
