# Hāpoyi UserBot 1.19.7

A modular Telegram MTProto userbot built on Telethon 1.45.0. The project is designed around real implementations rather than a command-name skeleton: persistent SQLite state, Telegram permission checks, pluggable providers, media tools, moderation, automation, games, market data, profile tools, scheduled jobs and an auditable source tree.


## Update 1.19.7 — Harbor
`.sb` for EVERY account (each in its own unix user inside the sandbox container) • `.sb domain add example.com` (owner): DNS check + SSL certificate at once, previews on https • `.mail`: temporary
mail panel (Get mail / Update / See all inboxes, pages) sent by your account via the Assistant Bot • glass panels (`.menu`, `.models`, `.mail`) answer only the account that opened them. Details: `docs/RELEASE_1.19.7.md`.

## Update 1.17.0 — Copilot

AI message ids (`#10001`), `.reply <id>`, `.storage on|off` (AI memory), thread-aware `.ask`, and AI account control `.do`
(the AI operates the self for you; first use asks for permanent permission). Details: `docs/RELEASE_1.17.0.md`.

## Update 1.16.0 — Atlas
Many free AI providers with unlimited keys and smart fail-over, `.models` glass panel, `.ask` with pictures, `.web`, `.imagine`,
token-free helper tips, `.aiknow` owner fix, server temp-file cleanup. Details: `docs/RELEASE_1.16.0.md`, keys & models: `docs/AI_PROVIDERS.md`.

## Update 1.15.2 — TikTok download fix

- TikTok `.dl` failed with `Unexpected response from webpage request`: `curl_cffi` (browser impersonation) was never installed and yt-dlp's warning about it was hidden. `requirements.txt` now installs it; yt-dlp warnings are logged. Run `pip install -U -r requirements.txt` and restart. See `docs/RELEASE_1.15.2.md`.

## Update 1.15.1 — Downloader format picker

- `.dl <link>` now opens a private inline choice for **MP4 video** or **MP3 audio** when the Assistant Bot is configured and Inline Mode is enabled in @BotFather.
- `.dl mp4 <link>` and `.dl mp3 <link>` choose an output directly; existing quality, Saved Messages, status, and link-reply options remain supported.
- The format buttons are bound to a random, short-lived request token and accept clicks only from the user who created that request.
- `.help`, the AI's live command manual, `docs/HELP.txt`, `.env.example`, and release notes now describe the new behavior.
- See `docs/RELEASE_1.15.1.md` for setup and test notes.

## Implemented in this release

- Telegram client bootstrap with `.env` configuration and local session storage.
- SQLite persistence using WAL and a busy timeout.
- Modular loader with per-module load status.
- Group moderation: ban, unban, kick, mute, unmute, delete, purge, pin, unpin, admins.
- Permission-aware failures for group admin rights.
- AutoBan with per-chat enable/disable, action selection and whitelist.
- AutoDelete by reply, @username or numeric ID, with activation timestamp so old messages are not retroactively deleted.
- Keyword filters and basic flood protection.
- Warnings with 3-warning mute behavior.
- AFK and return command.
- Notes, reminders, jobs, calculation, user/chat information and message search.
- Live profile clock and bio editor.
- Price editing: writing `دلار`, `بیت کوین`, `تتر`, `سولانا` and other configured aliases edits the user's own message into a quote containing USD value, Toman value when the local market provider resolves it, 24h change and minute timestamp.
- Price dashboard and one-shot alerts.
- Casino/dice/dart/bowling/basketball/football loops with cancellation and bounded roll count.
- Reactions and AutoReact.
- AutoReply with chat-local scope and optional regex mode in the database schema.
- Channel comments and comment reading.
- Media download, resize, rename, watermark and WebP conversion.
- Source-level security audit script.
- Systemd service file and Ubuntu installer.

## 🧠 What's new in 1.15.0

- **AI guide for the self itself** — `.guide <سؤال>` (and `.ask` whenever the question is about the bot) answers from the bot's own docs plus the notes the owner taught it (`.aiknow add / import / list / del`, main account only; every customer account reads them). It understands meaning in any language ("زمان‌بندی", "schedule", "تایم مسیج", "send later" → `.later` / `.every` / `.remind`) and answers on the account the self is running on, with that account's own daily AI quota.
- **Smart helper** — `.aiguide on|off`: when the owner looks confused, mistypes a command, gets an error or laughs, the AI decides from the situation whether to say something (silence is the default; `fun on|off`, `where chat|saved`, `ttl`, `here on|off`, `ctx on|off`). Off = only `.ask` / `.guide` answer.
- **Downloader** — `.dl <link>` for YouTube, Instagram and TikTok opens an owner-only inline picker for MP4 video or MP3 audio; `.dl mp4 <link>` and `.dl mp3 <link>` select directly. Also supports `.dl 480`, `.dl best`, `.dl me`, `.dl info`, `.yt/.ig/.tt`, and Persian «دانلود لینک». The picker uses the Assistant Bot (`BOT_TOKEN`) with Inline Mode enabled via `/setinline` in @BotFather; direct MP3/MP4 commands still work without the picker. Downloads run server-side with yt-dlp. See `docs/RELEASE_1.15.1.md`.
- Fixed: five `.help` sections printed a literal `\n` instead of a new line.
- Update: `pip install -r requirements.txt` (adds `yt-dlp` + `curl_cffi`; keep it fresh with `pip install -U "yt-dlp[default,curl-cffi]"`).

## ✨ What's new in 1.12.0

- `.download` / `دانلود` (Reply, any chat): the **server** downloads the media and re-uploads it to Saved Messages (great on weak internet; albums supported).
- `.ss` / `اسکرین` (Reply): renders the message as a phone-screenshot style sticker (avatar, sender name, time, Persian shaping). `.ss light`, `.ss quote`.
- `.menu` is posted through the bot's **inline mode**: it appears in any chat/PV/group in one step, even where the bot is not a member (enable once in @BotFather: `/setinline`). You can also type `@YourBot` in any chat. Falls back to a normal bot message when inline is off.
- Button panels next to the text sections (all text commands stay): friends/enemies, group (welcome, leave log, LinkGuard, locks, slow-mode), security (AutoBan, Safety Guard, Account Protect status), automation (AFK, every, AutoReply, scheduled deletes), media. Chat-scoped panels act on the chat where `.menu` was sent.
- `.xo`: two-player tic-tac-toe with inline buttons (also a button on the menu home).
- `.menu`: dashboard + live actions (AFK, every jobs, AutoReply, Todo, habits, expenses, unread, DB backup) per account.
- `.rps [N]`: two-player rock-paper-scissors with secret inline buttons (enable inline mode for the bot in @BotFather).
- `.every 10m 5 text` (max 5 messages, then it deletes itself), `.every 10m - text` (unlimited); interval range 1s … 72h.
- `modules/plus.py`: 15 new features (`.plus`), all stored in the account's own database.
- Fonts: `assets/fonts/` (DejaVu bundled; drop `Vazirmatn-Regular.ttf` / `Vazirmatn-Bold.ttf` there for a nicer Persian look).
- Existing installs: set `REPEAT_MIN_SECONDS=1` in `.env` (old default was 10) and run `pip install -r requirements.txt`.

## 🔐 Multi-account + licenses (v1.11.0)

The account in `.env` (`SESSION`) is the **main/owner** account. With `BOT_TOKEN` set, the control bot lets you create
licenses (hours / days / months); anybody holding a valid license can log **their own** account in through the bot and
the self runs on it **at the same time** as every other account (no limit, separate data per account). You can switch a
license off, delete it, or let it expire — the account is stopped and logged out. See `docs/RELEASE_1.11.0.md`.

Owner panel: type a duration (`30s`, `5min`, `12h`, `3d`, `1m` [+ name]) to create a license instantly, or press **➕ افزودن سلف به اکانت** to log any account in yourself (phone → code → 2FA, no license needed).

Extra commands: `.protect on|off|status`, `.mesdel all|N [chat]`, `.reactdel N|all [chat]`, `.lic ...` (main account).

## 🎛️ Control Center UI

`.menu` and `.panel` now open a real inline-button control center through an optional Assistant Bot. Telegram/Telethon expose callback-button reply markup to Bot accounts, so the privileged account stays a normal UserBot while the Assistant Bot renders the interactive UI.

Add these to `.env`:

```env
BOT_TOKEN=your_assistant_bot_token
UI_ENABLED=true
HAPOYI_BOT_SESSION=/root/HapoyiUserBot/data/hapoyi_ui_bot
```

The owner ID is discovered automatically at startup. Other users can see the panel but their callback clicks are rejected. In groups, the Assistant Bot must be a member and have permission to send messages.

## Safety and trust model

The source tree intentionally contains no remote plugin loader, remote Python-code executor, session exfiltration routine or telemetry system. Network access is limited to Telegram through Telethon plus explicitly configured data providers (market/FX). The security audit script reports hard-coded external URLs and obvious dynamic execution constructs.

This does **not** make third-party dependencies automatically trustworthy. Dependency trust is a separate boundary and should be reviewed when versions change.

## Run on Ubuntu

```bash
cd /root
unzip HapoyiUserBot-v1.0.0.zip
cd /root/HapoyiUserBot
cp .env.example .env
nano .env
python3 -m venv venv
./venv/bin/python -m pip install -U pip wheel
./venv/bin/python -m pip install -r requirements.txt
./venv/bin/python scripts/smoke_test.py
./venv/bin/python main.py
```

On first successful `client.start()`, Telethon may ask for the phone number, login code and 2FA password. Keep the resulting session file inside `data/`; never publish it.

## systemd

```bash
sudo cp systemd/hapoyi-userbot.service /etc/systemd/system/hapoyi-userbot.service
sudo systemctl daemon-reload
sudo systemctl enable --now hapoyi-userbot
sudo systemctl status hapoyi-userbot --no-pager
journalctl -u hapoyi-userbot -f
```

## Market price behavior

Examples:

```text
دلار
بیت کوین
تتر
سولانا

.price btc
.market
.alert btc > 120000
.alerts
```

The crypto provider resolves common aliases and caches quotes for a short period. USD crypto prices come from CoinGecko; local crypto/toman values use Nobitex public market statistics when the asset is available there. The local provider can be replaced through environment variables. Never treat any quote as a guaranteed executable price.

## Telegram capability boundary

This project targets the capabilities that can be implemented safely and reliably through a normal user account and current Telethon APIs. Some Telegram features are account-type dependent, require special permissions, or are Bot-only. Those are kept as explicit roadmap items instead of being falsely advertised as working.

## Tests

```bash
./venv/bin/python -m pytest -q
./venv/bin/python scripts/smoke_test.py
./venv/bin/python security/audit_source.py
```


## Package size note

The release archive is intentionally larger than 5 MB. It includes the real source tree, tests, documentation and a synthetic 75,000-row SQLite stress fixture. The fixture contains no real Telegram data and may be removed for production deployments that want a smaller archive.

## v1.1 additions

```text
.welcome on [template]
.leave on|off
.linkguard on|off [all|invite] [delete|warn|mute|ban] [duration]
.linkguard threshold <count> <window> <action> [duration]
.rate <count> <window>
.rate off
.delafter <duration>   # reply
.selfdestruct <duration> <text>
.cleanme [count]
.hold add <coin> <qty>
.hold set <coin> <qty>
.hold del <coin>
.portfolio
.notify add <chat> <keyword>
.notify del <chat> <keyword>
.notify list
```

## v1.3.0 additions

- **Smart Casino**: `.casino smart 777 [max_rolls]` and `.casino hooshmad 777 [max_rolls]`. The slot-machine win value `64` is used for Telegram's triple-7 outcome.
- Failed dice are deleted, command messages are removed, and the smart runner uses adaptive delay and stops on FloodWait/SlowMode/PeerFlood instead of trying to bypass Telegram controls.
- LinkGuard supports all links or Telegram invite links, immediate delete/warn/mute/ban actions, and rolling-window thresholds such as 100 links in 10 minutes.
- **Safety/Flood Guard**: `.safety on|off|status` and `.floodguard on|off|status`, with a per-chat circuit breaker.
- **Friend/Enemy relations**: `.friend add`, `.enemy add`, randomized reply pools, per-user/per-chat cooldown, custom reply pools, stats and cooldown control.
- **Help.txt**: `.help` sends a full text file; the Assistant Bot menu also exposes a Help.txt button.

### Example relations

```text
.friend add @ali
.enemy add @ali
.enemy reply تروخدا از ما بکش بیرون 😭
.relation replies enemy
.relation cooldown enemy 8
```

The project intentionally does **not** include anti-detection, mass-reporting, or other mechanisms designed to evade Telegram's anti-spam systems.


## GameForge 1.4.0

The game layer now includes a full Telegram slot-machine decoder for all 64 outcomes, exact reel targeting, count/pattern matching, smart search with FloodGuard, Telegram dice-family runners, local mini-games, persistent game stats and a per-chat leaderboard. See `docs/SLOT_64.txt` and `docs/RELEASE_1.4.md`.


## v1.5 additions

```text
.linkguard status
.linkguard on|off [all|invite] [delete|warn|mute|ban] [duration]
.linkguard threshold <count> <window> <delete|warn|mute|ban> [duration]
```

LinkGuard deletes detected links immediately, skips group administrators and whitelist entries, and can escalate after a rolling threshold such as 100 links in 10 minutes.

## 🔎 Private Audit Logger
The optional Audit Bot is separate from the main UserBot. The UserBot watches only chats you explicitly configure, stores observed message text locally so edits can show before/after content, and sends batched log entries to a private log group through `AUDIT_BOT_TOKEN`. It is a reliability-oriented logger: queueing, batching, and Telegram backoff reduce unnecessary sends; it does not attempt to bypass Telegram anti-spam or enforcement.

Set `AUDIT_BOT_TOKEN` and optionally `AUDIT_LOG_CHAT_ID`, add the Audit Bot to your private log group, then in the source chat run:

```text
.audit on
.audit status
.audit list
.audit test
.audit off
```

For a specific source/log pair:

```text
.audit on @source_chat -1001234567890
```

`MessageEdited` is handled by Telethon directly. The logger can only reconstruct the "before" text when it observed and stored that message before the edit; Telegram does not provide arbitrary historical versions of an edited message.

## What's new in 1.13.0
See `docs/RELEASE_1.13.0.md` (timer interval, unlimited fakes + `.stop fake all`, emoji-aware screenshots, XO Join + random start, `.report`, `.repeat`).
Third-party assets: `assets/emoji` = Twemoji (CC-BY 4.0), `assets/fonts/Vazirmatn-*` = OFL.

## What's new in 1.14.0
See `docs/RELEASE_1.14.0.md`. Put at least one of `GROQ_API_KEY`, `NVIDIA_API_KEY`, `OPENROUTER_API_KEY` in `.env` to use the AI commands; `pip install -r requirements.txt` (adds `edge-tts`).
