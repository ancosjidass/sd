# 1.15.1 — Downloader format picker

## MP4 / MP3 output selection

- `.dl <link>` opens an inline menu for YouTube, Instagram or TikTok links: **🎬 MP4 video**, **🎧 MP3 audio**, or cancel.
- `.dl mp4 <link>` and `.dl mp3 <link>` skip the menu and select the desired output immediately. Audio is extracted from video links by yt-dlp/FFmpeg.
- Reply to a message containing a supported link with `.dl` to open the same menu. `.dl me <link>` preserves the Saved Messages destination.
- The menu is served by the Assistant Bot. Set `BOT_TOKEN` in `.env`, then enable Inline Mode with `/setinline` in @BotFather. If Inline Mode is unavailable, the bot tries to post a normal button message where it has permission. Without an Assistant Bot, `.dl <link>` preserves the old direct-video behavior.
- Each menu uses a random short-lived token, has a 15-minute expiration, is single-use, and rejects button clicks from anyone other than the request owner.

## Updated AI help and config

`modules/help.py` is the live source for `.help` and the bot's AI manual. The downloader section and AI routing synonyms now describe the MP4/MP3 selection. `docs/HELP.txt`, `README.md`, `.env.example`, `VERSION.json` and `pyproject.toml` were updated as well.

## Validation

- Python compilation passed for the changed modules and project source.
- Downloader helper checks passed for MP3, MP4, quality-selection parsing and the three-platform host allow-list.
- A mocked integration check passed for an inline MP3 selection and direct MP4 delivery.
- The repository's pytest suite could not be collected in the build environment because `Telethon==1.45.0` is not installed and package downloads are unavailable; six dependency-light parser / formatting / link-guard tests passed.

## Upgrade

```bash
pip install -r requirements.txt
# Make sure ffmpeg is installed for MP3 conversion and video/audio merging.
# Configure BOT_TOKEN and enable /setinline in @BotFather for the inline format picker.
```
