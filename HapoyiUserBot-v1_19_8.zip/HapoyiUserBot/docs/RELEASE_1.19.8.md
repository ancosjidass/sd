# 1.19.8 — Harbor (fix)

## Fixed: `.sb domain add` said «wrong DNS» for correct records (and `.mail` then had no domain)
Causes found in `sandbox_server/domains.py`:
- Names were resolved through the container's own resolver (`getaddrinfo`): stale / negative caches (a record you just saved was "not there"), search domains of the host.
  Now the **authoritative name servers of the domain are asked first** (current records, no cache), then 1.1.1.1 / 8.8.8.8 / 9.9.9.9 (`SANDBOX_DNS_SERVERS`), the system resolver is the last resort.
- Every failure (timeout, no DNS) looked like «no record» = ❌. Now a lookup that could not be answered is ❓ (unknown) with a note to retry.
- The server's IP came from ONE service (`api.ipify.org`); if it was wrong (VPN / WARP / NAT) or unreachable, correct records were refused. Now: four services + the local public address,
  several IPs allowed (`SANDBOX_PUBLIC_IP=1.2.3.4,5.6.7.8`), and you can tell the check the IP yourself: `.sb domain add example.com 1.2.3.4`.
- The report now shows the IP it expects, the A / MX it found, and the reason in words (record missing, points to another IP, **Cloudflare proxy on (orange cloud → set DNS only)**, MX not pointing here).
- `.mail` without a mail domain now says how to see the reason (`.sb domain check`) and how to force it (`.sb domain mail <domain> on`).
- The SMTP receiver failing to start (port 25 busy / slow start) no longer takes the whole sandbox server down.

**Update:** replace the files, restart the bot, and REBUILD the sandbox: `cd sandbox_server && docker compose up -d --build` (the check runs inside that container). Then `.sb domain check example.com`.
Test: `tests/test_v1198_dns.py`.
