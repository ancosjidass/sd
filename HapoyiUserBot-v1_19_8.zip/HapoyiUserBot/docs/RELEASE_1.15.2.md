# 1.15.2 — TikTok download fix

**Symptom:** every TikTok `.dl` failed with `ERROR: [TikTok] ...: Unexpected response from webpage request`.

## Root cause
That exact message only exists in recent yt-dlp releases (it is absent in 2025.x and present from about 2026.3), so the
server's yt-dlp was already new enough. The message means: yt-dlp downloaded the TikTok page, but it was neither the
video page nor TikTok's JS challenge page, i.e. TikTok's anti-bot layer served something else.

TikTok only serves the real page to clients with a browser-like TLS fingerprint. yt-dlp gets that from the optional
`curl_cffi` package. Without it yt-dlp **only prints a warning** ("no impersonate target is available") and sends the
request anyway, so TikTok answers with the unexpected page. Three things in the project hid this:

1. `requirements.txt` never listed `curl_cffi` (and only said `yt-dlp>=2025.1.15`), so it was never installed.
2. The downloader ran yt-dlp with `no_warnings=True`, which threw the warning away.
3. The error text told you nothing about the cause.

## Changes
- `requirements.txt`: `yt-dlp[default,curl-cffi]>=2026.8.19`.
- yt-dlp warnings now go to the bot log instead of being discarded.
- A startup warning is logged when browser impersonation is unavailable.
- `.dl status` shows whether impersonation really works (not just whether `curl_cffi` is importable).
- The TikTok error now says which case you are in: curl_cffi missing/incompatible, or impersonation OK but the server IP is blocked.
- Removed a stale `yt_dlp-2025.1.15` wheel that was shipped in the zip root (unused by the install script).

## Upgrade
```bash
cd /root/HapoyiUserBot
/root/HapoyiUserBot/venv/bin/pip install -U -r requirements.txt
sudo systemctl restart hapoyi-userbot
```
Send `.dl status`: yt-dlp 2026.8.19 or newer and `curl_cffi ✅` mean it is fixed on the software side.
If TikTok still fails with the "IP is blocked" message, set `YTDLP_PROXY` (non-datacenter IP) or `YTDLP_COOKIES` in `.env`.

Note: the venv path must be the one in `systemd/hapoyi-userbot.service`; installing with a different pip does nothing.
