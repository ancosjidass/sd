"""Verified domains of the sandbox (1.19.7): `.sb domain add example.com` (owner only).

What happens when the owner adds a domain
  1. a sub-domain of a domain that already has SSL needs NOTHING (it is served and gets its own certificate on the first visit) -> status "covered";
  2. otherwise the DNS is looked at (A record = this server? MX = this server? does a random sub-domain answer too = wildcard?);
  3. the TLS proxy (Caddy, on-demand TLS) is asked for the certificate RIGHT NOW (one TLS handshake with that name) - no waiting for the first visitor;
  4. the domain is saved (data volume) and used for preview links (`https://domain/p/<secret>/`) and, if its MX points here, for `.mail`.

Caddy asks `/tls/ask?domain=x` before it orders any certificate; only a registered domain (or a sub-domain of one) is approved, so nobody can make the server order certificates for foreign names.

    SANDBOX_PUBLIC_IP   the public IPv4 of this server - several are allowed, separated by a comma (empty = found through ipify & co.)
    SANDBOX_TLS_HOST    host[:port] of the TLS proxy inside the compose network (caddy:443)
    SANDBOX_DNS_SERVERS the resolvers used for the DNS check (default 1.1.1.1,8.8.8.8,9.9.9.9); the authoritative name servers of the domain are asked FIRST, so a record you just
                        saved is seen at once (no stale cache of the container / the host)
    `.sb domain add example.com 1.2.3.4`  tells the check which IP is the server's (when the automatic detection is wrong: NAT, VPN / WARP on the server, several IPs)
"""
from __future__ import annotations

import asyncio
import ipaddress
import json
import os
import re
import secrets
import socket
import ssl
import threading
import time
from pathlib import Path

LABEL = r"(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)"
DOMAIN_RE = re.compile(rf"^(?=.{{4,253}}$)(?:{LABEL}\.)+(?=[a-z0-9-]*[a-z])[a-z0-9-]{{2,24}}$")
IP_RE = re.compile(r"^\d{1,3}(?:\.\d{1,3}){3}$")
FORBIDDEN_SUFFIX = (".local", ".localhost", ".internal", ".lan", ".home", ".arpa", ".test", ".invalid", ".example")


def normalize(name: str) -> str:
    n = (name or "").strip().lower()
    n = re.sub(r"^[a-z]+://", "", n).split("/")[0].split(":")[0].strip(".")
    if n.startswith("*."):
        n = n[2:]
    return n


def valid(name: str) -> bool:
    return bool(DOMAIN_RE.match(name)) and not IP_RE.match(name) and not name.endswith(FORBIDDEN_SUFFIX)


def is_sub_of(name: str, parent: str) -> bool:
    return name == parent or name.endswith("." + parent)


class Registry:
    """A tiny JSON file in the data volume. {name: {added, ssl, ssl_error, mail, wild_mx, a_ok, checked, covered_by}}."""

    def __init__(self, path: Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()

    def _load(self) -> dict:
        try:
            return json.loads(self.path.read_text("utf-8"))
        except (OSError, ValueError):
            return {}

    def _save(self, data: dict) -> None:
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=1), "utf-8")
        os.replace(tmp, self.path)

    def all(self) -> dict[str, dict]:
        with self._lock:
            return self._load()

    def get(self, name: str) -> dict | None:
        return self.all().get(name)

    def put(self, name: str, **fields) -> dict:
        with self._lock:
            data = self._load()
            row = data.setdefault(name, {"added": time.time()})
            row.update(fields)
            self._save(data)
            return dict(row)

    def remove(self, name: str) -> bool:
        with self._lock:
            data = self._load()
            if name not in data:
                return False
            data.pop(name)
            self._save(data)
            return True

    # ------------------------------------------------------------ rules
    def covering(self, name: str) -> str | None:
        """A REGISTERED PARENT (not the name itself) that already has SSL: then `name` needs nothing."""
        best = None
        for d, row in self.all().items():
            if d != name and is_sub_of(name, d) and row.get("ssl") and (best is None or len(d) < len(best)):
                best = d
        return best

    def allowed(self, name: str) -> bool:
        """Does the TLS proxy / the server answer for this host?  A registered domain or any sub-domain of one."""
        name = normalize(name)
        return valid(name) and any(is_sub_of(name, d) for d in self.all())

    def mail_domains(self) -> list[dict]:
        return [{"name": d, "wild_mx": bool(r.get("wild_mx"))} for d, r in sorted(self.all().items()) if r.get("mail")]

    def ssl_domains(self) -> list[str]:
        return [d for d, r in sorted(self.all().items()) if r.get("ssl")]

    def public_base(self) -> str:
        """https://<one of the domains that has SSL> (random, so previews spread over the domains), or ''."""
        ready = self.ssl_domains()
        return "https://" + secrets.choice(ready) if ready else ""


# ---------------------------------------------------------------- DNS / TLS (all of it is best effort and never raises)
# Bugs fixed in 1.19.8 (the check said "wrong records" for correct ones):
#   * names were resolved through the resolver of the container (getaddrinfo): stale / negative caches, search domains of the host -> now the authoritative name servers of the
#     domain are asked first, then public resolvers, the system resolver is only the last resort;
#   * every failure (timeout, dnspython missing) looked like "no record" -> now a lookup that could not be done is "unknown" (❓), not "wrong" (❌);
#   * ONE detection of the server IP (api.ipify.org) decided everything -> several services, several IPs (SANDBOX_PUBLIC_IP=a,b), and `.sb domain add <domain> <ip>`;
#   * the report did not say which IP it expected -> it does now (and says when the name is behind the Cloudflare proxy).
PUBLIC_RESOLVERS = [x for x in re.split(r"[,\s]+", os.getenv("SANDBOX_DNS_SERVERS", "").strip() or "1.1.1.1,8.8.8.8,9.9.9.9") if x]
IP_SERVICES = ("https://api.ipify.org", "https://checkip.amazonaws.com", "https://icanhazip.com", "https://ifconfig.me/ip")
CLOUDFLARE_NETS = tuple(ipaddress.ip_network(n) for n in (
    "173.245.48.0/20", "103.21.244.0/22", "103.22.200.0/22", "103.31.4.0/22", "141.101.64.0/18", "108.162.192.0/18", "190.93.240.0/20", "188.114.96.0/20",
    "197.234.240.0/22", "198.41.128.0/17", "162.158.0.0/15", "104.16.0.0/13", "104.24.0.0/14", "172.64.0.0/13", "131.0.72.0/22"))
_ip_cache: dict = {"ip": "", "at": 0.0}


def valid_ip(text: str) -> bool:
    try:
        return isinstance(ipaddress.ip_address((text or "").strip()), ipaddress.IPv4Address)
    except ValueError:
        return False


def ip_set(text: str) -> set[str]:
    """'1.2.3.4' / '1.2.3.4, 5.6.7.8' -> {'1.2.3.4', '5.6.7.8'} (only valid IPv4 addresses)."""
    return {x for x in re.split(r"[,\s;]+", text or "") if x and valid_ip(x)}


def behind_cloudflare(ips: list[str]) -> bool:
    for x in ips:
        try:
            if any(ipaddress.ip_address(x) in net for net in CLOUDFLARE_NETS):
                return True
        except ValueError:
            continue
    return False


def _local_public_ip() -> str:
    """The address this machine uses to reach the internet, when it is public (not inside Docker / behind NAT)."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
        finally:
            s.close()
        return ip if ipaddress.ip_address(ip).is_global else ""
    except (OSError, ValueError):
        return ""


async def server_ip() -> str:
    """The public IPv4 of this server; several addresses are joined with a comma. SANDBOX_PUBLIC_IP wins over the detection."""
    env = ip_set(os.getenv("SANDBOX_PUBLIC_IP", ""))
    if env:
        return ",".join(sorted(env))
    if _ip_cache["ip"] and time.time() - _ip_cache["at"] < 3600:
        return _ip_cache["ip"]
    found: set[str] = set()
    try:
        import aiohttp

        async def one(url: str) -> str:
            try:
                async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=6)) as s:
                    async with s.get(url) as r:
                        return (await r.text()).strip()
            except Exception:  # noqa: BLE001
                return ""

        for text in await asyncio.gather(*(one(u) for u in IP_SERVICES)):
            if valid_ip(text):
                found.add(text)
    except Exception:  # noqa: BLE001
        pass
    local = _local_public_ip()
    if local:
        found.add(local)
    if found:
        _ip_cache.update(ip=",".join(sorted(found)), at=time.time())
        return _ip_cache["ip"]
    return ""


async def _ask(name: str, rdtype: str, nameservers: list[str] | None = None, lifetime: float = 4.0) -> tuple[list, str]:
    """One DNS question -> (answers, status): status "ok" (answers), "none" (NXDOMAIN / no such record: a real answer) or "error" (timeout, no resolver, dnspython missing: we do NOT know).
    nameservers=None -> the resolver of the container."""
    try:
        import dns.asyncresolver  # noqa: PLC0415
        import dns.resolver  # noqa: PLC0415
    except ImportError:                                  # dnspython is not installed: we cannot know
        return [], "error"
    try:
        res = dns.asyncresolver.Resolver(configure=nameservers is None)
        if nameservers:
            res.nameservers = list(nameservers)
        res.lifetime = lifetime
        res.timeout = min(2.0, lifetime)
        answers = await res.resolve(name, rdtype, search=False)
        return list(answers), "ok"
    except (dns.resolver.NXDOMAIN, dns.resolver.NoAnswer):
        return [], "none"
    except Exception:  # noqa: BLE001  (timeout, SERVFAIL, no resolver configured ...)
        return [], "error"


async def authoritative_servers(name: str) -> list[str]:
    """IPs of the name servers of the zone of `name` (walks up: sub.example.com -> example.com). They answer with the CURRENT records, no cache in between."""
    labels = name.split(".")
    for i in range(max(1, len(labels) - 1)):
        zone = ".".join(labels[i:])
        answers, _ = await _ask(zone, "NS", PUBLIC_RESOLVERS)
        if not answers:
            continue
        ips: list[str] = []
        for host in [str(r.target).rstrip(".") for r in answers][:4]:
            addrs, _ = await _ask(host, "A", PUBLIC_RESOLVERS)
            ips += [r.address for r in addrs]
        return ips[:6]
    return []


async def _lookup(name: str, rdtype: str, auth: list[str] | None = None) -> tuple[list, bool]:
    """-> (answers, reliable). Order: the authoritative servers (a definite answer from them is final), the public resolvers, the resolver of the container.
    reliable=False: no question could be answered at all (then an empty list means «unknown», not «no record»)."""
    if auth:
        answers, status = await _ask(name, rdtype, auth, 3.0)
        if status != "error":
            return answers, True
    answered = False
    for servers in (PUBLIC_RESOLVERS, None):
        answers, status = await _ask(name, rdtype, servers)
        if answers:
            return answers, True
        answered = answered or status == "none"
    return [], answered


async def lookup_a(name: str, auth: list[str] | None = None) -> tuple[list[str], bool]:
    answers, reliable = await _lookup(name, "A", auth)
    found = sorted({r.address for r in answers})
    if not found and not reliable:                       # dnspython missing / no DNS at all: the last resort is the resolver of the system
        try:
            infos = await asyncio.get_running_loop().getaddrinfo(name, None, family=socket.AF_INET, type=socket.SOCK_STREAM)
            found = sorted({i[4][0] for i in infos})
            reliable = bool(found)
        except OSError:
            pass
    return found, reliable


async def lookup_mx(name: str, auth: list[str] | None = None) -> tuple[list[tuple[int, str]], bool]:
    answers, reliable = await _lookup(name, "MX", auth)
    return sorted((int(r.preference), str(r.exchange).rstrip(".").lower()) for r in answers), reliable


async def resolve_a(name: str) -> list[str]:
    return (await lookup_a(name))[0]


async def resolve_mx(name: str) -> list[tuple[int, str]]:
    return (await lookup_mx(name))[0]


async def dns_report(name: str, ip: str) -> dict:
    """a_ok: the name points to this server (None = we do not know: our own IP, or the DNS, could not be found out);  mx_ok: some MX host of the name points to this server;
    wild_a / wild_mx: a random sub-domain answers too (needed for mail addresses with a sub-domain label).  `ip` may hold several addresses separated by a comma."""
    ips = ip_set(ip)
    probe = "zz" + secrets.token_hex(3) + "." + name
    auth = await authoritative_servers(name)
    (a, a_rel), (mx, mx_rel), (wa, _), (wmx, _) = await asyncio.gather(lookup_a(name, auth), lookup_mx(name, auth), lookup_a(probe, auth), lookup_mx(probe, auth))
    mx_a: dict[str, list[str]] = {}

    async def host_ips(host: str) -> list[str]:
        if host == name:
            return a
        if host not in mx_a:
            mx_a[host] = (await lookup_a(host, auth if is_sub_of(host, name) else None))[0]
        return mx_a[host]

    async def points_here(hosts: list[tuple[int, str]]) -> bool:
        for _, host in hosts:
            found = await host_ips(host)
            if (ips and ips & set(found)) or (not ips and found):
                return True
        return False

    if a:
        a_ok: bool | None = bool(ips & set(a)) if ips else None
    else:
        a_ok = False if a_rel else None
    mx_ok = await points_here(mx)
    return {"ip": ip, "expected": sorted(ips), "a": a, "a_ok": a_ok, "mx": [h for _, h in mx], "mx_ok": mx_ok if (mx_ok or mx_rel) else None,
            "wild_a": bool(wa) and (bool(ips & set(wa)) if ips else True), "wild_mx": bool(wmx) and await points_here(wmx),
            "cloudflare": behind_cloudflare(a), "lookup_failed": not (a_rel and mx_rel)}


async def warm_tls(name: str, timeout: float = 75.0) -> tuple[bool, str]:
    """One TLS handshake with that name through the proxy: Caddy orders the certificate during it (on-demand TLS), so the cert exists when this returns.
    The handshake VERIFIES the certificate (public CA chain + the name), so `True` means a real, valid certificate."""
    host = os.getenv("SANDBOX_TLS_HOST", "").strip()
    if not host:
        return False, "no TLS proxy configured (SANDBOX_TLS_HOST) - use the docker-compose of sandbox_server/ (Caddy)"
    h, _, p = host.partition(":")
    ctx = ssl.create_default_context()
    try:
        reader, writer = await asyncio.wait_for(asyncio.open_connection(h, int(p or 443), ssl=ctx, server_hostname=name), timeout)
        writer.close()
        try:
            await writer.wait_closed()
        except Exception:  # noqa: BLE001
            pass
        return True, ""
    except asyncio.TimeoutError:
        return False, f"the certificate was not ready after {int(timeout)} s"
    except ssl.SSLError as exc:
        return False, "no valid certificate yet: " + str(exc)[:150]
    except OSError as exc:
        return False, f"the TLS proxy is not reachable: {exc.__class__.__name__}"


def dns_hint(name: str, ip: str) -> str:
    ip = ",".join(sorted(ip_set(ip))) or "<IP-سرور>"
    return (f"رکوردهای لازم:\n  A   {name}   {ip}\n  A   *.{name}   {ip}      (برای زیردامنه‌ها)\n"
            f"  MX  {name}   10 {name}      (برای .mail)\n  MX  *.{name}   10 {name}  (برای ایمیل با زیردامنهٔ تصادفی)")


def dns_problems(name: str, report: dict) -> list[str]:
    """Why the check is not green, in words (for the report of `.sb domain add`)."""
    out: list[str] = []
    expected = ", ".join(report.get("expected") or []) or "؟"
    a = report.get("a") or []
    if report.get("lookup_failed"):
        out.append("⚠️ بعضی پرسش‌های DNS جواب نگرفتند (timeout)؛ نتیجه قطعی نیست. چند دقیقه بعد دوباره `.sb domain check` بزن.")
    if not a and report.get("a_ok") is False:
        out.append(f"رکورد A برای {name} پیدا نشد (هنوز ثبت یا پخش نشده).")
    elif a and report.get("a_ok") is False:
        if report.get("cloudflare"):
            out.append("دامنه پشت پروکسی Cloudflare است (ابر نارنجی). رکوردهای A و MX را روی «DNS only» (ابر خاکستری) بگذار.")
        else:
            out.append(f"رکورد A به {', '.join(a[:3])} اشاره می‌کند ولی IP این سرور {expected} است. اگر IP سرور را درست می‌دانی و تشخیص خودکار اشتباه است: `.sb domain add {name} <IP-سرور>`")
    if report.get("mx_ok") is False:
        mx = report.get("mx") or []
        out.append(f"MX برای {name} {'روی ' + ', '.join(mx[:3]) + ' است که به این سرور نمی‌رسد' if mx else 'پیدا نشد'}.")
    return out


async def add_or_check(reg: Registry, raw: str, *, warm: bool = True, ip: str = "") -> dict:
    """The whole `.sb domain add` / `check` flow -> a report for the bot.  `ip`: the owner says which IP is this server's (`.sb domain add example.com 1.2.3.4`)."""
    name = normalize(raw)
    if not valid(name):
        return {"ok": False, "error": "نام دامنه معتبر نیست (مثال: example.com)"}
    override = ",".join(sorted(ip_set(ip)))
    if ip.strip() and not override:
        return {"ok": False, "error": "IP معتبر نیست (باید IPv4 باشد، مثال: 1.2.3.4)"}
    parent = reg.covering(name)
    if parent:
        reg.put(name, covered_by=parent)
        return {"ok": True, "status": "covered", "domain": name, "by": parent,
                "note": f"{name} زیردامنهٔ {parent} است که SSL دارد؛ کاری لازم نیست."}
    ip = override or await server_ip()
    report = await dns_report(name, ip)
    row = reg.put(name, a_ok=report["a_ok"], mx_ok=report["mx_ok"], wild_mx=report["wild_mx"], mail=bool(report["mx_ok"]) or bool((reg.get(name) or {}).get("mail_forced")),
                  checked=time.time(), covered_by=None)
    ssl_ok, ssl_err = False, "DNS هنوز به این سرور نمی‌رسد"
    if report["a_ok"] is not False and warm:
        ssl_ok, ssl_err = await warm_tls(name)
    row = reg.put(name, ssl=ssl_ok, ssl_error=ssl_err if not ssl_ok else "")
    problems = dns_problems(name, report)
    return {"ok": True, "status": "ready" if ssl_ok else "pending", "domain": name, "ssl": ssl_ok, "ssl_error": ssl_err, "dns": report, "mail": bool(row.get("mail")),
            "problems": problems, "hint": "" if (ssl_ok and row.get("mail")) else dns_hint(name, ip)}
