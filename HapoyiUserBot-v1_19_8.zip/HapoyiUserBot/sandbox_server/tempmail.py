"""Temporary mail boxes (module tempmail) of the sandbox (1.19.7): `.mail` in Telegram.

An address is made on request of an account (`/mail/new`), looks like  `abcd@efgh.example.com`  (4-7 random letters / digits; a random sub-domain label of 4-7 characters is put in
front of the domain only when that domain answers for sub-domains, see domains.py `wild_mx`) and lives MAIL_TTL_HOURS (24 h). The SMTP receiver accepts a mail ONLY for an address that exists
(everything else is refused with 550), keeps at most 40 mails per address and 60 000 characters per mail, and the owner of the address (the account / session) is the only one who can read it.

    SANDBOX_SMTP_PORT   2525   (docker-compose maps the host port 25 to it)     SANDBOX_SMTP_HOST 0.0.0.0     SANDBOX_MAIL_TTL_HOURS 24
"""
from __future__ import annotations

import email
import email.policy
import html as htmllib
import os
import random
import re
import secrets
import sqlite3
import string
import threading
import time
from pathlib import Path

MAX_PER_ADDRESS = 40
MAX_ADDRESSES = 30                 # per session; the oldest is dropped
MAX_BODY = 60_000
LOCAL_CHARS = string.ascii_lowercase + string.digits
_rng = random.SystemRandom()


def ttl_seconds() -> float:
    return float(os.getenv("SANDBOX_MAIL_TTL_HOURS", "24") or 24) * 3600


def rand_label(lo: int = 4, hi: int = 7) -> str:
    """4-7 characters, starts with a letter (looks like a name, never like a number)."""
    n = _rng.randint(lo, hi)
    return _rng.choice(string.ascii_lowercase) + "".join(_rng.choice(LOCAL_CHARS) for _ in range(n - 1))


def html_to_text(raw: str) -> str:
    raw = re.sub(r"(?is)<(script|style)\b.*?</\1>", " ", raw)
    raw = re.sub(r"(?i)<br\s*/?>|</p>|</div>|</tr>|</h\d>", "\n", raw)
    raw = re.sub(r"(?s)<[^>]+>", " ", raw)
    raw = htmllib.unescape(raw)
    return re.sub(r"[ \t]+", " ", re.sub(r"\n\s*\n+", "\n\n", raw)).strip()


def parse_message(data: bytes) -> dict:
    msg = email.message_from_bytes(data, policy=email.policy.default)
    body = ""
    try:
        part = msg.get_body(preferencelist=("plain", "html"))
        if part is not None:
            body = part.get_content()
            if part.get_content_type() == "text/html":
                body = html_to_text(body)
    except Exception:  # noqa: BLE001  (a broken charset must not lose the mail)
        body = data.decode("utf-8", "replace")
    attachments = [p.get_filename() for p in msg.iter_attachments() if p.get_filename()] if msg.is_multipart() else []
    return {"sender": str(msg.get("from") or "")[:300], "subject": str(msg.get("subject") or "(بدون موضوع)")[:300], "body": (body or "").strip()[:MAX_BODY],
            "attachments": attachments[:10]}


class Store:
    def __init__(self, path: Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        with self._conn() as c:
            c.executescript("""
                CREATE TABLE IF NOT EXISTS addresses(id INTEGER PRIMARY KEY AUTOINCREMENT, session TEXT NOT NULL, addr TEXT NOT NULL UNIQUE, created REAL NOT NULL);
                CREATE INDEX IF NOT EXISTS ix_addr_session ON addresses(session, created);
                CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY AUTOINCREMENT, aid INTEGER NOT NULL, sender TEXT, subject TEXT, body TEXT, attachments TEXT, ts REAL NOT NULL);
                CREATE INDEX IF NOT EXISTS ix_msg_aid ON messages(aid, ts);
            """)

    def _conn(self) -> sqlite3.Connection:
        c = sqlite3.connect(str(self.path), timeout=10, check_same_thread=False)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA foreign_keys=OFF")
        return c

    # ------------------------------------------------------------ addresses
    def new_address(self, session: str, domains: list[dict]) -> dict:
        """domains: [{"name": "example.com", "wild_mx": bool}] (only those that can receive mail). Raises ValueError when there is none."""
        if not domains:
            raise ValueError("no mail domain")
        with self._lock, self._conn() as c:
            for _ in range(50):
                d = _rng.choice(domains)
                host = d["name"]
                if d.get("wild_mx") and _rng.random() < 0.5:
                    host = f"{rand_label()}.{host}"
                addr = f"{rand_label()}@{host}"
                if not c.execute("SELECT 1 FROM addresses WHERE addr=?", (addr,)).fetchone():
                    break
            else:
                raise ValueError("could not find a free address")
            now = time.time()
            cur = c.execute("INSERT INTO addresses(session,addr,created) VALUES(?,?,?)", (session, addr, now))
            rows = c.execute("SELECT id FROM addresses WHERE session=? ORDER BY created DESC, id DESC", (session,)).fetchall()
            for old in rows[MAX_ADDRESSES:]:
                self._drop(c, int(old["id"]))
            return {"id": int(cur.lastrowid), "addr": addr, "created": now, "expires": now + ttl_seconds(), "count": 0}

    @staticmethod
    def _drop(c: sqlite3.Connection, aid: int) -> None:
        c.execute("DELETE FROM messages WHERE aid=?", (aid,))
        c.execute("DELETE FROM addresses WHERE id=?", (aid,))

    def list_addresses(self, session: str) -> list[dict]:
        with self._conn() as c:
            rows = c.execute("""SELECT a.id, a.addr, a.created, COUNT(m.id) AS n, COALESCE(MAX(m.ts),0) AS last FROM addresses a LEFT JOIN messages m ON m.aid=a.id
                                WHERE a.session=? GROUP BY a.id ORDER BY a.created DESC, a.id DESC""", (session,)).fetchall()
        ttl = ttl_seconds()
        return [{"id": int(r["id"]), "addr": r["addr"], "created": r["created"], "expires": r["created"] + ttl, "count": int(r["n"]), "last": r["last"]} for r in rows]

    def address(self, session: str, aid: int) -> dict | None:
        with self._conn() as c:
            r = c.execute("SELECT id, addr, created FROM addresses WHERE id=? AND session=?", (int(aid), session)).fetchone()
        return {"id": int(r["id"]), "addr": r["addr"], "created": r["created"], "expires": r["created"] + ttl_seconds()} if r else None

    def delete_address(self, session: str, aid: int) -> bool:
        with self._lock, self._conn() as c:
            if not c.execute("SELECT 1 FROM addresses WHERE id=? AND session=?", (int(aid), session)).fetchone():
                return False
            self._drop(c, int(aid))
        return True

    def exists(self, addr: str) -> bool:
        with self._conn() as c:
            return c.execute("SELECT 1 FROM addresses WHERE addr=?", ((addr or "").strip().lower(),)).fetchone() is not None

    # ------------------------------------------------------------ messages
    def add_message(self, addr: str, parsed: dict) -> bool:
        with self._lock, self._conn() as c:
            row = c.execute("SELECT id FROM addresses WHERE addr=?", ((addr or "").strip().lower(),)).fetchone()
            if not row:
                return False
            aid = int(row["id"])
            c.execute("INSERT INTO messages(aid,sender,subject,body,attachments,ts) VALUES(?,?,?,?,?,?)",
                      (aid, parsed.get("sender", ""), parsed.get("subject", ""), parsed.get("body", ""), "\n".join(parsed.get("attachments") or []), time.time()))
            c.execute("DELETE FROM messages WHERE aid=? AND id NOT IN (SELECT id FROM messages WHERE aid=? ORDER BY id DESC LIMIT ?)", (aid, aid, MAX_PER_ADDRESS))
        return True

    def messages(self, session: str, aid: int, limit: int = 6, offset: int = 0) -> dict:
        a = self.address(session, aid)
        if a is None:
            return {"ok": False, "error": "no such inbox"}
        with self._conn() as c:
            total = c.execute("SELECT COUNT(*) FROM messages WHERE aid=?", (int(aid),)).fetchone()[0]
            rows = c.execute("SELECT id, sender, subject, substr(body,1,160) AS preview, ts FROM messages WHERE aid=? ORDER BY id DESC LIMIT ? OFFSET ?",
                             (int(aid), max(1, min(int(limit), 20)), max(0, int(offset)))).fetchall()
        return {"ok": True, "address": a, "total": int(total),
                "items": [{"id": int(r["id"]), "sender": r["sender"], "subject": r["subject"], "preview": r["preview"], "ts": r["ts"]} for r in rows]}

    def message(self, session: str, aid: int, mid: int) -> dict | None:
        if self.address(session, aid) is None:
            return None
        with self._conn() as c:
            r = c.execute("SELECT * FROM messages WHERE id=? AND aid=?", (int(mid), int(aid))).fetchone()
        if not r:
            return None
        return {"id": int(r["id"]), "sender": r["sender"], "subject": r["subject"], "body": r["body"], "attachments": [x for x in (r["attachments"] or "").split("\n") if x], "ts": r["ts"]}

    def purge(self) -> int:
        cutoff = time.time() - ttl_seconds()
        with self._lock, self._conn() as c:
            ids = [int(r["id"]) for r in c.execute("SELECT id FROM addresses WHERE created<?", (cutoff,)).fetchall()]
            for i in ids:
                self._drop(c, i)
        return len(ids)


# ---------------------------------------------------------------- the SMTP receiver (aiosmtpd runs it in its own thread)
class SMTPHandler:
    def __init__(self, store: Store):
        self.store = store

    async def handle_RCPT(self, server, session, envelope, address, rcpt_options):
        addr = (address or "").strip().lower()
        if not self.store.exists(addr):
            return "550 5.1.1 no such mailbox"
        envelope.rcpt_tos.append(addr)
        return "250 OK"

    async def handle_DATA(self, server, session, envelope):
        parsed = parse_message(envelope.original_content or envelope.content or b"")
        got = False
        for rcpt in envelope.rcpt_tos:
            got = self.store.add_message(rcpt, parsed) or got
        return "250 OK" if got else "550 5.1.1 no such mailbox"


def start_smtp(store: Store):
    """-> the aiosmtpd controller (stop it with .stop()), or None when aiosmtpd is not installed / SANDBOX_SMTP_PORT=0."""
    port = int(os.getenv("SANDBOX_SMTP_PORT", "2525") or 0)
    if not port:
        return None
    try:
        from aiosmtpd.controller import Controller
    except ImportError:
        return None
    try:                                                  # a busy port 25 / a slow start must not take the whole sandbox down (domains, `.sb` ... keep working)
        ctrl = Controller(SMTPHandler(store), hostname=os.getenv("SANDBOX_SMTP_HOST", "0.0.0.0"), port=port, data_size_limit=2_000_000, server_hostname="mail.sandbox",
                          ready_timeout=15.0)
        ctrl.start()
    except Exception as exc:  # noqa: BLE001
        print(f"[tempmail] the SMTP receiver did not start on port {port}: {exc.__class__.__name__}: {exc}", flush=True)
        return None
    return ctrl
