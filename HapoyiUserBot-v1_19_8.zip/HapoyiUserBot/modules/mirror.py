"""Repeat (mirror): your account repeats EXACTLY what a chosen person writes, as a reply to his message.

    .repeat on [@user|id]     (or Reply to him)   start repeating him in THIS chat only
    .repeat off [@user|id]    (or Reply)          stop repeating him here;  `.repeat off all` = everybody in this chat
    .repeat list [all]                            who is repeated here (all = every chat)
    .repeat status                                switch state + counts
    .repeat clear [allchats]                      delete every repeat target of this chat (or of every chat)
    .repeat pause|resume                          global switch (targets are kept)
(Persian aliases: ریپیت)

Rules
  * Scope is (chat, user): turning it on for Hossein in group A does nothing in group B, even if you are in both.
  * Every new message of the target (text with its formatting, photo, sticker, voice, file ...) is sent again by your
    account as a REPLY to that message.
  * If the target types one of your self-commands (`.ban`, `.mute` ...) your account still SENDS the text, but the
    self never EXECUTES it (same protection as Echo).
"""
from __future__ import annotations

import logging
import os
import re
import time
from collections import OrderedDict
from datetime import datetime, timezone

from telethon import events
from telethon.errors import FloodWaitError, RPCError

from core.guard import add_echo_check
from core.identity import my_id
from core.permissions import resolve_target
from utils.activity import display_name
from utils.targets import target_label

log = logging.getLogger(__name__)
PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
P = re.escape(PREFIX)
COOLDOWN = float(os.getenv("REPEAT_USER_COOLDOWN", "0.4") or 0.4)
PENDING_TTL = 20.0
MAX_IDS = 5000

TABLES = """
CREATE TABLE IF NOT EXISTS repeat_targets (chat_id INTEGER NOT NULL, user_id INTEGER NOT NULL, name TEXT, created_at TEXT NOT NULL, PRIMARY KEY(chat_id, user_id))
"""


def setup(client, db):
    ids: "OrderedDict[tuple[int, int], bool]" = OrderedDict()
    pending: list[tuple[int, str, float]] = []
    last_use: dict[tuple[int, int], float] = {}
    ready = {"done": False}

    def _remember(chat_id: int, message_id: int) -> None:
        ids[(int(chat_id), int(message_id))] = True
        while len(ids) > MAX_IDS:
            ids.popitem(last=False)

    def is_repeat_event(event) -> bool:
        """True for a message this module sent (so the owner's commands never fire on it)."""
        chat_id = int(getattr(event, "chat_id", 0) or 0)
        key = (chat_id, int(getattr(event, "id", 0) or 0))
        if key in ids:
            return True
        now = time.monotonic()
        pending[:] = [x for x in pending if x[2] > now]
        text = (getattr(event, "raw_text", "") or "").strip()
        for i, (chat, t, _) in enumerate(pending):
            if chat == chat_id and t == text:  # the outgoing update can arrive before send_message() returns
                pending.pop(i)
                _remember(*key)
                return True
        return False

    add_echo_check(client, is_repeat_event)

    async def _ensure() -> None:
        if not ready["done"]:
            ready["done"] = True
            await db.execute(TABLES)

    async def _paused() -> bool:
        return bool(await db.get_kv("repeat_paused", False))

    # ------------------------------------------------------------------ the repeater
    @client.on(events.NewMessage(incoming=True))
    async def repeat_watcher(event):
        if getattr(event, "out", False) or not event.sender_id:
            return
        await _ensure()
        chat, sender = int(event.chat_id), int(event.sender_id)
        row = await db.fetchone("SELECT 1 FROM repeat_targets WHERE chat_id=? AND user_id=?", (chat, sender))
        if not row or await _paused():
            return
        if getattr(event.message, "action", None) is not None:
            return  # service messages
        now = time.monotonic()
        if now - last_use.get((chat, sender), 0.0) < COOLDOWN:
            return
        last_use[(chat, sender)] = now
        text = (event.raw_text or "").strip()
        reply_to = event.id
        if text:
            pending.append((chat, text, now + PENDING_TTL))  # register BEFORE sending (race with our own outgoing update)
        try:
            sent = await client.send_message(chat, event.message, reply_to=reply_to, link_preview=False)
        except FloodWaitError as exc:
            pending[:] = [x for x in pending if not (x[0] == chat and x[1] == text)]
            log.warning("repeat: flood wait %ss in %s", exc.seconds, chat)
            return
        except Exception as exc:  # noqa: BLE001 - e.g. media that cannot be copied
            pending[:] = [x for x in pending if not (x[0] == chat and x[1] == text)]
            log.info("repeat: could not copy message in %s: %s", chat, exc.__class__.__name__)
            return
        if sent is not None:
            _remember(chat, sent.id)

    # ------------------------------------------------------------------ management
    HELP = (
        "🔂 Repeat (ریپیت)\n"
        f"`{PREFIX}repeat on [@user|id]` (یا Reply) — از این به بعد هر پیامش را عیناً Reply می‌کنم (فقط همین گپ)\n"
        f"`{PREFIX}repeat off [@user|id]` (یا Reply) | `{PREFIX}repeat off all` — خاموش‌کردن\n"
        f"`{PREFIX}repeat list [all]` | `{PREFIX}repeat status` | `{PREFIX}repeat clear [allchats]`\n"
        f"`{PREFIX}repeat pause|resume` — کلید کلی\n"
        "دستورهای سلفی که او بزند فرستاده می‌شود ولی اجرا نمی‌شود."
    )

    @client.on(events.NewMessage(outgoing=True, pattern=rf"(?s)^(?:{P}repeat|ریپیت)(?:\s+(.*))?$"))
    async def repeat_cmd(event):
        await _ensure()
        parts = (event.pattern_match.group(1) or "").split()
        word = parts[0].lower() if parts else ""
        chat = event.chat_id

        if word in {"", "status"}:
            n = await db.fetchone("SELECT COUNT(*) AS n FROM repeat_targets WHERE chat_id=?", (chat,))
            t = await db.fetchone("SELECT COUNT(*) AS n FROM repeat_targets")
            return await event.reply(
                f"🔂 Repeat: {'⏸ PAUSED' if await _paused() else 'ON'}\nهدف‌ها در این گپ: {n['n']} | در همهٔ گپ‌ها: {t['n']}\n\n{HELP}")
        if word in {"pause", "resume"}:
            await db.set_kv("repeat_paused", word == "pause")
            return await event.reply("⏸ Repeat متوقف شد (هدف‌ها حفظ شد)." if word == "pause" else "▶️ Repeat ادامه پیدا کرد.")
        if word == "list":
            everywhere = len(parts) > 1 and parts[1].lower() == "all"
            rows = await db.fetchall("SELECT chat_id,user_id,name FROM repeat_targets" + ("" if everywhere else " WHERE chat_id=?")
                                     + " ORDER BY chat_id,created_at", () if everywhere else (chat,))
            if not rows:
                return await event.reply("🔂 لیست Repeat خالی است.")
            lines = [f"🔂 هدف‌ها ({len(rows)})"] + [f"• {r['name'] or '—'} ({r['user_id']})" + (f" — chat {r['chat_id']}" if everywhere else "") for r in rows]
            return await event.reply("\n".join(lines)[:3900])
        if word == "clear":
            if len(parts) > 1 and parts[1].lower() == "allchats":
                await db.execute("DELETE FROM repeat_targets")
                return await event.reply("🗑 Repeat همهٔ گپ‌ها پاک شد.")
            await db.execute("DELETE FROM repeat_targets WHERE chat_id=?", (chat,))
            return await event.reply("🗑 Repeat این گپ پاک شد.")
        if word in {"on", "add", "off", "del", "remove", "rm"}:
            turning_on = word in {"on", "add"}
            if not turning_on and len(parts) > 1 and parts[1].lower() == "all":
                await db.execute("DELETE FROM repeat_targets WHERE chat_id=?", (chat,))
                return await event.reply("🗑 Repeat همهٔ افراد این گپ خاموش شد.")
            user = await resolve_target(event, parts[1] if len(parts) > 1 else None, bare_ok=True)
            if user is None:
                return await event.reply(f"❌ کاربر پیدا نشد. Reply کن یا `{PREFIX}repeat {word} @username` بزن.")
            uid = int(user.id)
            if uid == await my_id(client):
                return await event.reply("❌ نمی‌توانی روی خودت Repeat بگذاری.")
            if getattr(user, "bot", False) and turning_on:
                return await event.reply("❌ روی ربات‌ها Repeat نمی‌شود.")
            if turning_on:
                await db.execute(
                    "INSERT INTO repeat_targets(chat_id,user_id,name,created_at) VALUES(?,?,?,?) ON CONFLICT(chat_id,user_id) DO UPDATE SET name=excluded.name",
                    (chat, uid, display_name(user, str(uid)), datetime.now(timezone.utc).isoformat()))
                return await event.reply(f"🔂 Repeat روی {target_label(user)} در همین گپ روشن شد.")
            n = await db.execute("DELETE FROM repeat_targets WHERE chat_id=? AND user_id=?", (chat, uid))
            return await event.reply(f"✅ Repeat {target_label(user)} خاموش شد." if n else f"ℹ️ {target_label(user)} در لیست Repeat نبود.")
        await event.reply("❌ فرمت نامعتبر.\n\n" + HELP)
