"""Keeps the server disk empty of leftovers.

Downloads (`.dl`, `.download`, `.sticker`, `.gif`, ...) delete their own files the moment they are uploaded to Telegram. This module is the
safety net for the cases nobody can predict (the process was killed mid-download, the server rebooted, an unexpected error):

* at start-up and then every 10 minutes everything in data/media, data/dl and data/clone_tmp that is idle for longer than
  TMP_MAX_AGE_MIN minutes (default 30) is deleted - folders of downloads that are running right now are never touched;
* `.storage`          free disk space + what the bot keeps in its temp folders
* `.storage clean`    delete every temp file that is not part of a running download

.env:  TMP_MAX_AGE_MIN=30   TMP_SWEEP_SECONDS=600
"""
from __future__ import annotations

import asyncio
import logging
import os
import re

from telethon import events

from utils import tmpclean

log = logging.getLogger(__name__)
PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
P = re.escape(PREFIX)
_STARTED = {"task": None}


def _num(name: str, default: float) -> float:
    try:
        return max(1.0, float(os.getenv(name, "") or default))
    except ValueError:
        return default


def _mb(n: float) -> str:
    return f"{n / 1048576:.1f} MB"


async def _loop() -> None:
    max_age = _num("TMP_MAX_AGE_MIN", 30) * 60
    every = _num("TMP_SWEEP_SECONDS", 600)
    first = True
    while True:
        try:
            # the very first pass runs in a fresh process: whatever is left over is from a previous run
            removed, freed = await asyncio.to_thread(tmpclean.sweep_all, 120 if first else max_age)
            first = False
            if removed:
                log.info("storage janitor: removed %d leftover item(s), %s", removed, _mb(freed))
        except Exception:  # noqa: BLE001 - the janitor must never die
            log.exception("storage janitor pass failed")
        await asyncio.sleep(every)


def start_janitor() -> None:
    """One background sweeper per process, however many accounts are running."""
    task = _STARTED["task"]
    if task is None or task.done():
        _STARTED["task"] = asyncio.get_running_loop().create_task(_loop(), name="storage-janitor")


async def setup(client, db):
    start_janitor()

    @client.on(events.NewMessage(outgoing=True, pattern=rf"(?i)^{P}storage(?:\s+(clean))?$"))
    async def storage(event):
        if event.pattern_match.group(1):
            removed, freed = await asyncio.to_thread(tmpclean.sweep_all, 0)
            return await event.reply(f"🧹 {removed} مورد پاک شد ({_mb(freed)} آزاد شد). دانلودهای در حال اجرا دست نخورد.")
        use = tmpclean.usage()
        lines = [f"• {name}: {_mb(size)}" for name, size in use.items()] or ["• چیزی نیست"]
        await event.reply(f"💾 فضای خالی سرور: {tmpclean.free_mb():.0f} MB\nفایل‌های موقت ربات:\n" + "\n".join(lines)
                          + f"\n\n`{PREFIX}storage clean` پاک‌سازی دستی\n🧠 حافظهٔ گفتگوی AI: `{PREFIX}storage on|off|status`")
