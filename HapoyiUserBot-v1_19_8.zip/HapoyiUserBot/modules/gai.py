"""The group's AI (1.19.5): ONE brain for «ربات ...» (admins / delegates) and `.gai do ...` (you). It manages the group.

    .gai on|off|status          (you, in the group)  switches it on - and the group-management mode of `.gbot` with it
    .gai word add|del <word>    the words that call it (default: هاپویی / hapoyi / ربات / بات)
    .gai do <request>           YOU talk to it (any account, main or second). Also `.gai ask <request>` and just `.gai <request>`.
                                «.gai do کپچا رو روشن کن و ۵۰ پیام آخر رو پاک کن»
    ربات <request>              an admin / a delegate writes it (also `.gai do <request>` from their account) - EXACTLY the same commands and the same
                                understanding as `.gai do`; the only difference is the rights check (an admin cannot do more than his own rights, a
                                delegate of level `mod` cannot promote; level `god` can do everything, also on admins - as far as YOUR account can).

Every GROUP feature is reachable from both (mute ban kick warn del purge delmes pin lock slowmode poll sched modai captcha linkguard filter flood welcome
autoban whitelist blacklist activity tag autodelete promote demote) - and NOTHING that belongs to your own account (`.every`, `.sum`, friends, auto-replies,
downloads, `.do`, licenses, backups).

Reply (1.19.5): Reply on a person's message + «ربات سکوتش کن» -> the AI sees WHO wrote it and WHAT it says, and the command acts on that person. When the AI
asks you something («کدوم کاربر؟»), just Reply to its question with the answer (a numeric id, @username, a duration ...): it remembers the request and
finishes the job - no calling word needed in that Reply.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import time
from collections import defaultdict, deque
from datetime import datetime
from zoneinfo import ZoneInfo

from telethon import events

from core import secretguard as SG
from telethon.errors import FloodWaitError

from core.identity import my_id
from core.permissions import get_real_reply, require_group_right
from services import aiagent as A
from services import knowledge as K
from services.aithreads import looks_like_ai_text, publish, split_bubble

log = logging.getLogger(__name__)
PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
P = re.escape(PREFIX)
TZ = os.getenv("TIMEZONE", "Asia/Tehran") or "Asia/Tehran"
TABLE = "CREATE TABLE IF NOT EXISTS gai_chats (chat_id INTEGER PRIMARY KEY, enabled INTEGER NOT NULL DEFAULT 1, words TEXT NOT NULL DEFAULT '[]')"
DEFAULT_WORDS = ("هاپویی", "hapoyi", "ربات", "بات")
PER_USER_GAP = 1.0
PER_CHAT_PER_MIN = 30
AI_DEADLINE = 45.0          # seconds: the AI never leaves a request hanging - it answers or says why not
THREAD_TTL = 900            # a question of the AI can be answered by Reply for this long
THREAD_MAX = 300
HISTORY_LIMIT = 120
OWNER_PER_MIN = 30
NEEDS_TARGET = frozenset({"mute", "unmute", "ban", "unban", "kick", "warn", "unwarn", "warnings", "del", "pin", "promote", "demote", "delall"})
SUBCOMMANDS = frozenset({"on", "off", "status", "word"})
CMD_FORM = re.compile(rf"(?is)^\s*(?:{P}|/)gai(?:@\w+)?(?:\s+(.*))?$")
SEND_GAP = A.SEND_GAP


def trigger_split(text: str, words) -> str | None:
    """'ربات این رو میوت کن' -> 'این رو میوت کن'; None when the message does not start with a calling word."""
    t = K.norm(text or "")
    raw = (text or "").strip()
    for w in sorted((K.norm(x) for x in words), key=len, reverse=True):
        if not w:
            continue
        m = re.match(rf"^{re.escape(w)}(?:[\s,،:؛!]+)(.+)$", t, re.S)
        if m and len(m.group(1).strip()) >= 3:
            # cut the SAME number of characters from the raw text (the raw one keeps the writing as the admin typed it)
            rest = re.sub(rf"^\s*\S{{{len(w)}}}[\s,،:؛!]+", "", raw, count=1, flags=re.S)
            return (rest or m.group(1)).strip()
    return None


def command_split(text: str) -> str | None:
    """`.gai do کپچا رو روشن کن` / `.gai ask ...` / `.gai ...` written by somebody else (an admin or delegate) -> the request; None for `.gai on|off|status|word`
    (those are the owner's switches) or an empty request. (1.19.5: «.gai do» from a delegate's account did nothing at all before.)"""
    m = CMD_FORM.match(text or "")
    if not m:
        return None
    rest = (m.group(1) or "").strip()
    first = rest.split(None, 1)[0].lower() if rest else ""
    if first in {"do", "ask"}:
        rest = strip_verbs(rest)
    elif first in SUBCOMMANDS or not rest:
        return None
    return rest or None


def strip_verbs(text: str) -> str:
    """`ask do سکوتش کن` / `do سکوتش کن` -> `سکوتش کن` (the leading do / ask words are only the verb of the command)."""
    t = (text or "").strip()
    for _ in range(2):
        head = t.split(None, 1)
        if head and head[0].lower() in {"do", "ask"}:
            t = head[1].strip() if len(head) > 1 else ""
    return t


def has_explicit_person(args: str) -> bool:
    first = (args or "").split(None, 1)[0] if (args or "").strip() else ""
    return bool(re.match(r"^(@\w+|-?\d{5,}|tg://\S+|\S*t\.me/\S+)$", first))


def setup(client, db):
    st = {"ready": False, "gap": {}, "chat_times": defaultdict(deque), "cache": {}, "owner_times": deque(), "threads": {}, "tasks": set()}
    client._hapoyi_gai_state = st

    async def ensure() -> None:
        if not st["ready"]:
            st["ready"] = True
            await db.execute(TABLE)

    async def cfg_of(chat_id: int):
        hit = st["cache"].get(chat_id)
        if hit and time.monotonic() - hit[0] < 15:
            return hit[1]
        row = await db.fetchone("SELECT * FROM gai_chats WHERE chat_id=?", (chat_id,))
        row = dict(row) if row else None
        st["cache"][chat_id] = (time.monotonic(), row)
        return row

    def words_of(cfg) -> tuple[str, ...]:
        try:
            extra = tuple(json.loads(cfg["words"] or "[]"))
        except (ValueError, TypeError):
            extra = ()
        return DEFAULT_WORDS + extra

    def spawn(coro) -> None:
        task = asyncio.get_running_loop().create_task(coro)
        st["tasks"].add(task)
        task.add_done_callback(st["tasks"].discard)

    async def name_of(m) -> str:
        snd = getattr(m, "sender", None)
        if snd is None:
            try:
                snd = await m.get_sender()
            except Exception:  # noqa: BLE001
                snd = None
        return " ".join(x for x in (getattr(snd, "first_name", None), getattr(snd, "last_name", None)) if x) or getattr(snd, "title", None) or getattr(snd, "username", None) or str(getattr(m, "sender_id", None) or "?")

    async def history(event, limit: int = HISTORY_LIMIT) -> list[dict]:
        zone = ZoneInfo(TZ)
        today = datetime.now(zone).date()
        rows = []
        try:
            msgs = await client.get_messages(event.chat_id, limit=limit)
        except Exception:  # noqa: BLE001
            return rows
        for m in reversed(list(msgs or [])):
            if getattr(m, "action", None) is not None or m.id == getattr(event, "id", None):
                continue
            when = m.date.astimezone(zone) if m.date else None
            snd = getattr(m, "sender", None)
            who = " ".join(x for x in (getattr(snd, "first_name", None), getattr(snd, "last_name", None)) if x) or getattr(snd, "title", None) or getattr(snd, "username", None) or str(m.sender_id or "?")
            rows.append({"id": m.id, "t": (when.strftime("%H:%M") if when and when.date() == today else (when.strftime("%m-%d %H:%M") if when else "")),
                         "who": who, "text": (getattr(m, "message", "") or "").strip() or "[media]"})
        return rows

    def media_kind(m) -> str:
        for attr, label in (("photo", "photo"), ("video", "video"), ("voice", "voice message"), ("audio", "audio"), ("sticker", "sticker"), ("gif", "gif"), ("document", "file")):
            if getattr(m, attr, None):
                return label
        return "text message"

    async def reply_info(replied):
        """What the AI is told about the replied message: its id, author (name + id) and TEXT - so «سکوتش کن» / «این چی میگه؟» can be understood."""
        if replied is None:
            return None
        me = await my_id(client)
        return {"kind": media_kind(replied), "who": await name_of(replied), "who_id": getattr(replied, "sender_id", None), "id": replied.id,
                "text": (getattr(replied, "message", "") or "").strip(), "mine": getattr(replied, "sender_id", None) == me}

    # ------------------------------------------------------------------ Reply on the AI's own question = a follow-up (it remembers the request)
    def remember(chat: int, msg, request: str, answer: str, target) -> None:
        mid = getattr(msg, "id", None)
        if not mid:
            return
        now = time.monotonic()
        for k in [k for k, v in st["threads"].items() if now - v["born"] > THREAD_TTL]:
            st["threads"].pop(k, None)
        while len(st["threads"]) >= THREAD_MAX:
            st["threads"].pop(next(iter(st["threads"])), None)
        st["threads"][(chat, int(mid))] = {"request": request[:600], "answer": answer[:600], "target_id": getattr(target, "id", None), "born": now}

    def thread_of(chat: int, msg_id) -> dict | None:
        th = st["threads"].get((chat, int(msg_id))) if msg_id else None
        if th and time.monotonic() - th["born"] > THREAD_TTL:
            st["threads"].pop((chat, int(msg_id)), None)
            return None
        return th

    async def followup(event, replied):
        """(the message the request is about, follow-up context text). A Reply on one of the AI's own messages continues THAT job."""
        if replied is None:
            return None, ""
        chat = int(event.chat_id)
        th = thread_of(chat, replied.id)
        if th:
            ctx = f'Earlier request: "{th["request"]}"\nYou answered: "{th["answer"]}"'
            tgt = None
            if th.get("target_id"):
                try:
                    tgt = await client.get_messages(chat, ids=th["target_id"])
                except Exception:  # noqa: BLE001
                    tgt = None
                if tgt is not None:
                    ctx += f"\n(The earlier request was about message #{tgt.id}, shown as the replied message.)"
            return tgt, ctx
        if getattr(replied, "sender_id", None) == await my_id(client) and looks_like_ai_text(getattr(replied, "message", None)):
            q, a = split_bubble(getattr(replied, "message", None))
            return None, f'Earlier request: "{q[:600]}"\nYou answered: "{a[:600]}"'
        return replied, ""

    # ------------------------------------------------------------------ the ONE planner (admins, delegates and the owner)
    async def plan_request(event, request: str, replied, *, owner: bool, asker: str = ""):
        """-> (plan | None, the message the request acts on, error text | None)."""
        ask = getattr(client, "_hapoyi_ask_ai", None)
        if ask is None:
            return None, replied, "❌ ماژول AI بارگذاری نشده (`.health`)."
        replied, context = await followup(event, replied)
        rows = await history(event) if A.wants_history(request) else []
        messages = A.build_group_messages(request, prefix=PREFIX, reply_info=await reply_info(replied), asker=asker, history=rows or None, owner=owner, context=context,
                                          now_text=datetime.now(ZoneInfo(TZ)).strftime("%Y-%m-%d %H:%M"))
        try:
            out, err = await asyncio.wait_for(ask(messages, max_tokens=900, temperature=0.1), AI_DEADLINE)
        except asyncio.TimeoutError:
            return None, replied, f"⏳ AI تا {int(AI_DEADLINE)} ثانیه جواب نداد؛ دوباره بنویس."
        if not out:
            return None, replied, err or "⚠️ AI جواب نداد؛ کمی بعد دوباره بنویس."   # the real reason (no key / quota), never a silent nothing
        known = set(A.OWNER_GROUP_COMMANDS if owner else A.GROUP_COMMANDS)
        plan = A.parse_plan(out, PREFIX, known, has_reply=replied is not None, ids={r["id"] for r in rows})
        if plan is None:
            return None, replied, "🤖 متوجه نشدم؛ کوتاه‌تر و واضح‌تر بنویس (مثلاً «ربات این رو میوت کن» با Reply)."
        return plan, replied, None

    async def target_of(a, replied, chat_id):
        """The message a command must be sent as a Reply to: the one the AI picked from the history, else the replied one for every command that
        needs a person / a message (even when the model forgot `on_reply`)."""
        if a.reply_id:
            try:
                return await client.get_messages(chat_id, ids=a.reply_id)
            except Exception:  # noqa: BLE001
                return None
        args = a.text[len(PREFIX) + len(a.name):].strip()
        if replied is not None and (a.on_reply or (a.name in NEEDS_TARGET and not has_explicit_person(args))):
            return replied
        return None

    # ------------------------------------------------------------------ others (admins / delegates) talk to the AI
    @client.on(events.NewMessage(incoming=True))
    async def talk(event):
        try:
            if not event.is_group or event.out or not event.raw_text or not event.sender_id:
                return
            await ensure()
            cfg = await cfg_of(int(event.chat_id))
            if not cfg or not cfg["enabled"]:
                return
            request = trigger_split(event.raw_text, words_of(cfg)) or command_split(event.raw_text)
            if request is None and event.is_reply and thread_of(int(event.chat_id), getattr(event, "reply_to_msg_id", None)):
                request = event.raw_text.strip()       # the answer to the AI's own question: no calling word needed
            if not request:
                return
            gb = getattr(client, "_hapoyi_groupbot", None)
            if gb is None or getattr(client, "_hapoyi_ask_ai", None) is None:
                return
            who = await gb.identify(event, need_gbot=False)   # `.gai on` is the switch here; `.gbot off` must not silence it
            if who is None:
                return
            why = SG.probe(request)
            if why:                                           # 1.19.6: source / tokens / shell / «ignore your instructions» from a non-owner never reaches the AI
                log.warning("gai: refused a %s request from %s in %s", why, event.sender_id, event.chat_id)
                await gb.say(event, SG.REFUSAL)
                return
            chat, uid = int(event.chat_id), int(event.sender_id)
            now = time.monotonic()
            if now - st["gap"].get((chat, uid), 0) < PER_USER_GAP:
                return
            st["gap"][(chat, uid)] = now
            q = st["chat_times"][chat]
            while q and now - q[0] > 60:
                q.popleft()
            if len(q) >= PER_CHAT_PER_MIN:
                return
            q.append(now)
            spawn(run(event, request, who, gb))     # in the background: nothing waits for the AI
        except Exception:  # noqa: BLE001
            log.exception("gai failed")

    async def run(event, request: str, who: dict, gb) -> None:
        try:
            replied = await get_real_reply(event)
            if replied is not None and getattr(replied, "action", None) is not None:
                replied = None
            try:
                asker = (await event.get_sender()).first_name or ""
            except Exception:  # noqa: BLE001
                asker = ""
            plan, replied, err = await plan_request(event, request, replied, owner=False, asker=asker)
            if plan is None:
                await gb.say(event, err)
                return
            acts = [a for a in plan.actions if a.kind == "cmd"][:A.GROUP_MAX_ACTIONS]
            ran = 0
            first_target = None
            for i, a in enumerate(acts):
                target = await target_of(a, replied, event.chat_id)
                first_target = first_target or target
                if i:
                    await asyncio.sleep(0.4)
                args = a.text[len(PREFIX) + len(a.name):].strip()
                ok = await gb.run_command(event, a.name, args, target, who, quiet=False)
                ran += 1 if ok else 0
            text = plan.clarify or plan.reply
            if plan.clarify and not acts:
                # the question stays (5 min) so it can be answered by Reply - and the AI remembers what the job was
                note = await gb.say(event, "❓ " + plan.clarify[:300], keep=THREAD_TTL / 3)
                remember(int(event.chat_id), note, request, plan.clarify, replied or first_target)
            elif text and (ran or not acts):
                await gb.say(event, "🤖 " + text[:300], keep=15)
            if plan.rejected and not acts:
                await gb.say(event, "🚫 این کار برای AI گروه ممکن نیست.")
            elif not acts and not text:
                await gb.say(event, "🤷 دستور گروهی‌ای برای اجرا پیدا نشد.")
        except Exception as exc:  # noqa: BLE001
            log.exception("gai run failed")
            await gb.say(event, f"⚠️ انجام نشد ({exc.__class__.__name__}). دوباره بنویس.")

    # ------------------------------------------------------------------ `.gai do`: YOU talk to the group AI (same planner, same commands as «ربات ...»)
    async def owner_do(event, request: str) -> None:
        if not event.is_group:
            return await event.edit("❌ `.gai do` فقط در گروه کار می‌کند.")
        feed = getattr(client, "_hapoyi_feed_handlers", None)
        if feed is None or getattr(client, "_hapoyi_ask_ai", None) is None:
            return await event.edit("❌ ماژول AI بارگذاری نشده (`.health`).")
        now = time.monotonic()
        q = st["owner_times"]
        while q and now - q[0] > 60:
            q.popleft()
        if len(q) >= OWNER_PER_MIN:
            return await event.edit("⏳ خیلی سریع شد؛ چند ثانیه صبر کن.")
        q.append(now)
        replied = await get_real_reply(event)
        if replied is not None and getattr(replied, "action", None) is not None:
            replied = None
        await event.edit("🤖 …")
        plan, replied, err = await plan_request(event, request, replied, owner=True)
        if plan is None:
            return await event.edit(err)
        # only group commands, only in THIS chat: plain texts and "saved messages" actions of the plan are ignored, the name is checked once more
        acts = [a for a in plan.actions if a.kind == "cmd" and a.name in A.OWNER_GROUP_COMMANDS][:A.OWNER_GROUP_MAX_ACTIONS]
        done: list[str] = []
        failed: list[tuple[str, str]] = []
        first_target = None
        for i, a in enumerate(acts):
            if i:
                await asyncio.sleep(SEND_GAP)
            kw = {"link_preview": False, "parse_mode": None}
            rep_msg = await target_of(a, replied, event.chat_id)
            first_target = first_target or rep_msg
            args = a.text[len(PREFIX) + len(a.name):].strip()
            if a.name in NEEDS_TARGET and rep_msg is None and not has_explicit_person(args):
                failed.append((a.text, "روی پیام فرد Reply کن یا @username/شناسه بده"))
                continue
            if rep_msg is not None:
                kw["reply_to"] = rep_msg.id
            try:
                sent = await client.send_message(event.chat_id, a.text, **kw)
                await feed(sent, event, rep_msg)
                done.append(a.text if len(a.text) <= 100 else a.text[:97] + "…")
            except FloodWaitError as exc:
                failed.append((a.text, f"FloodWait {getattr(exc, 'seconds', '?')}s — بقیه متوقف شد"))
                break
            except Exception as exc:  # noqa: BLE001
                log.warning("gai do: sending %r failed: %s", a.text[:60], exc.__class__.__name__)
                failed.append((a.text, exc.__class__.__name__))
        await asyncio.sleep(0.2)
        lines = [plan.clarify and f"❓ {plan.clarify}\n(با Reply روی همین پیام جواب بده)" or plan.reply or ("✅ انجام شد." if done else "🤷 دستور گروهی‌ای برای اجرا پیدا نشد.")]
        if done:
            lines.append("▶️ از اکانت تو فرستاده شد:\n" + "\n".join(f"• `{c}`" for c in done))
        if failed:
            lines.append("⚠️ انجام نشد:\n" + "\n".join(f"• `{c}` ({why})" for c, why in failed))
        if plan.rejected:
            lines.append("\n".join(f"🚫 `{w}` — {why}" for w, why in plan.rejected[:6]))
        await publish(client, db, event, f"🤖 {request[:80]}", "\n\n".join(lines), kind="do", question=request[:1500])
        remember(int(event.chat_id), event, request, plan.clarify or plan.reply or "", replied or first_target)

    # ------------------------------------------------------------------ the owner switches it
    @client.on(events.NewMessage(outgoing=True, pattern=rf"(?s)^{P}gai(?:\s+(.*))?$"))
    async def gai_cmd(event):
        await ensure()
        raw = (event.pattern_match.group(1) or "").strip()
        parts0 = raw.split(None, 1)
        first = parts0[0].lower() if parts0 else ""
        if first in {"do", "ask"} or (raw and first not in SUBCOMMANDS):
            request = strip_verbs(raw) if first in {"do", "ask"} else raw
            if not request:
                return await event.reply(f"فرمت: `{PREFIX}gai do درخواستت` — مثال: `{PREFIX}gai do کپچا رو روشن کن` | `{PREFIX}gai do ۵۰ تا پیام آخر رو پاک کن` "
                                         f"| (Reply) `{PREFIX}gai do این رو یک روز میوت کن`")
            return await owner_do(event, request)
        if not event.is_group:
            return await event.reply("❌ فقط در گروه.")
        chat = int(event.chat_id)
        parts = (raw or "status").split()
        word = parts[0].lower()
        cfg = await cfg_of(chat)
        if word == "on":
            perm = await require_group_right(client, chat, "ban_users")
            if not perm.allowed:
                return await event.reply("❌ خودت باید ادمین با حق Ban Users باشی: " + perm.reason)
            await db.execute("INSERT INTO gai_chats(chat_id,enabled) VALUES(?,1) ON CONFLICT(chat_id) DO UPDATE SET enabled=1", (chat,))
            await db.execute("CREATE TABLE IF NOT EXISTS gb_chats (chat_id INTEGER PRIMARY KEY, enabled INTEGER NOT NULL DEFAULT 1)")
            await db.execute("INSERT INTO gb_chats(chat_id,enabled) VALUES(?,1) ON CONFLICT(chat_id) DO UPDATE SET enabled=1", (chat,))
            st["cache"].pop(chat, None)
            return await event.reply("🤖 AI گروه روشن شد. ادمین‌ها (و کسانی که با `.delegate` دسترسی دادی) می‌تونن با «ربات …» یا «هاپویی …» (یا `.gai do …`) ازش کار بخوان؛ "
                                     "فقط به اندازهٔ دسترسی خودشون — با همان امکاناتی که `.gai do` برای خودت داره.\nمثال: «ربات این رو تا فردا ساعت ۱۰ میوت کن» (Reply)\n"
                                     "اگه چیزی پرسید، روی همان پیامش Reply کن و جواب بده.\n"
                                     f"⚠️ پیام «ربات …» فقط از بقیه (ادمین‌ها / دسترسی‌دارها) کار می‌کنه، نه از خود اکانتت (برای خودت: `{PREFIX}gai do …`).")
        if word == "off":
            await db.execute("UPDATE gai_chats SET enabled=0 WHERE chat_id=?", (chat,))
            st["cache"].pop(chat, None)
            return await event.reply("🤖 AI گروه خاموش شد.")
        if word == "word" and len(parts) >= 3 and parts[1].lower() in {"add", "del"}:
            w = " ".join(parts[2:]).strip()
            await db.execute("INSERT INTO gai_chats(chat_id,enabled) VALUES(?,0) ON CONFLICT(chat_id) DO NOTHING", (chat,))
            cur = list(json.loads((await cfg_of(chat) or {}).get("words", "[]") or "[]")) if await cfg_of(chat) else []
            if parts[1].lower() == "add" and w not in cur:
                cur.append(w)
            if parts[1].lower() == "del":
                cur = [x for x in cur if x != w]
            await db.execute("UPDATE gai_chats SET words=? WHERE chat_id=?", (json.dumps(cur, ensure_ascii=False), chat))
            st["cache"].pop(chat, None)
            return await event.reply("🔤 کلمه‌های صدازدن: " + " ، ".join(DEFAULT_WORDS + tuple(cur)))
        on = bool(cfg and cfg["enabled"])
        await event.reply(f"🤖 AI گروه: {'روشن' if on else 'خاموش'}" + ((" • کلمه‌ها: " + " ، ".join(words_of(cfg))) if cfg else "")
                          + f"\n`{PREFIX}gai on|off` | `{PREFIX}gai word add|del <کلمه>` | `{PREFIX}gai do <درخواست>`")
